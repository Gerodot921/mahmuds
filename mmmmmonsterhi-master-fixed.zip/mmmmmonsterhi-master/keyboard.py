from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def get_restore_keyboard(products: list[dict]) -> InlineKeyboardMarkup:
    keyboard = []

    for product in products:
        product_id = product.get("id_goods")
        game_name = product.get("game_name", "Неизвестная игра")

        keyboard.append([
            InlineKeyboardButton(
                text=f"Вернуть «{game_name}» в продажу",
                callback_data=f"ggsel_restore:{product_id}",
            )
        ])

    return InlineKeyboardMarkup(inline_keyboard=keyboard)