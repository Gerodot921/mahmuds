import asyncio
import hashlib
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import HTTPException

from ggsel.webhook import GgselWebhook
from ggsel.webhook_message import GgselMessageWebhook


def make_signature(unique_code: str, invoice_id: str, product_id: str) -> str:
    value = f"{unique_code};{invoice_id};{product_id}"
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


@pytest.mark.asyncio
async def test_ggsel_webhook_accepts_valid_sale_and_starts_processing():
    db = MagicMock()
    db.insert_webhook_sale = AsyncMock(return_value=True)

    processor = MagicMock()
    processor.process_by_invoice = AsyncMock()

    webhook = GgselWebhook(
        db=db,
        processor=processor,
        unique_code="UNIQUE_CODE",
    )

    invoice_id = "12345"
    product_id = "67890"
    payload = {
        "ID_I": invoice_id,
        "ID_D": product_id,
        "Amount": "12.50",
        "Currency": "RUB",
        "Date": "2026-08-21",
        "SHA256": make_signature("UNIQUE_CODE", invoice_id, product_id),
    }

    response = await webhook.handle(payload)

    assert response == {"ok": True}
    db.insert_webhook_sale.assert_awaited_once_with(
        invoice_id=invoice_id,
        ggsel_product_id=int(product_id),
        amount=12.5,
        currency="RUB",
        sale_date="2026-08-21",
        raw_data=payload,
    )

    await asyncio.sleep(0.01)
    processor.process_by_invoice.assert_awaited_once_with(invoice_id)


@pytest.mark.asyncio
async def test_ggsel_webhook_rejects_invalid_signature():
    db = MagicMock()
    db.insert_webhook_sale = AsyncMock()

    processor = MagicMock()
    processor.process_by_invoice = AsyncMock()

    webhook = GgselWebhook(
        db=db,
        processor=processor,
        unique_code="UNIQUE_CODE",
    )

    with pytest.raises(HTTPException) as exc:
        await webhook.handle(
            {
                "ID_I": "123",
                "ID_D": "456",
                "Amount": 10,
                "Currency": "RUB",
                "Date": "2026-08-21",
                "SHA256": "wrong-signature",
            }
        )

    assert exc.value.status_code == 403
    db.insert_webhook_sale.assert_not_awaited()
    processor.process_by_invoice.assert_not_awaited()


@pytest.mark.asyncio
async def test_ggsel_webhook_ignores_duplicate_sale():
    db = MagicMock()
    db.insert_webhook_sale = AsyncMock(return_value=False)

    processor = MagicMock()
    processor.process_by_invoice = AsyncMock()

    webhook = GgselWebhook(
        db=db,
        processor=processor,
        unique_code="UNIQUE_CODE",
    )

    invoice_id = "321"
    product_id = "654"
    response = await webhook.handle(
        {
            "ID_I": invoice_id,
            "ID_D": product_id,
            "Amount": 99,
            "Currency": "RUB",
            "Date": "2026-08-21",
            "SHA256": make_signature("UNIQUE_CODE", invoice_id, product_id),
        }
    )

    assert response == {"ok": True}
    await asyncio.sleep(0.01)
    processor.process_by_invoice.assert_not_awaited()


@pytest.mark.asyncio
async def test_message_webhook_returns_steam_guard_code():
    db = MagicMock()
    db.get_sale = AsyncMock(return_value={"id": 11, "invoice_id": "123"})
    db.get_rental_by_invoice_id = AsyncMock(
        return_value={"kosell_rental_uid": "rental-uid-777"}
    )
    db.add_event = AsyncMock()

    ggsel = MagicMock()
    ggsel.send_message = AsyncMock()

    kosell = MagicMock()
    kosell.get_steam_guard_code = AsyncMock(return_value={"code": "ABCD-1234"})

    webhook = GgselMessageWebhook(
        db=db,
        ggsel=ggsel,
        kosell=kosell,
    )

    response = await webhook.handle(
        {
            "DebateId": "42",
            "MessageId": None,
            "OwnerId": None,
            "MessageDate": "2026-08-21T12:00:00Z",
            "Message": "код",
            "InvoiceId": "123",
            "ImagePath": "",
        }
    )

    assert response == {"ok": True}
    db.add_event.assert_awaited_once()
    kosell.get_steam_guard_code.assert_awaited_once_with(rental_uid="rental-uid-777")
    ggsel.send_message.assert_awaited_once_with(
        debate_id=123,
        message="Steam Guard code: ABCD-1234",
    )


@pytest.mark.asyncio
async def test_message_webhook_ignores_unknown_invoice():
    db = MagicMock()
    db.get_sale = AsyncMock(return_value=None)

    ggsel = MagicMock()
    ggsel.send_message = AsyncMock()

    kosell = MagicMock()
    kosell.get_steam_guard_code = AsyncMock()

    webhook = GgselMessageWebhook(
        db=db,
        ggsel=ggsel,
        kosell=kosell,
    )

    response = await webhook.handle(
        {
            "DebateId": "42",
            "MessageId": None,
            "OwnerId": None,
            "MessageDate": "2026-08-21T12:00:00Z",
            "Message": "code",
            "InvoiceId": "missing-invoice",
            "ImagePath": "",
        }
    )

    assert response == {"ok": True}
    kosell.get_steam_guard_code.assert_not_awaited()
    ggsel.send_message.assert_not_awaited()
