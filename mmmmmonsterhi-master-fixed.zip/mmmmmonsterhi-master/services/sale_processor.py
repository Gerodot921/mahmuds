from __future__ import annotations

import logging
from collections.abc import Mapping
from html import escape
from typing import Any

import httpx
from aiogram import Bot
from aiogram.types import Message

from db import Database
from ggsel.ggsel_session import GgselClient
from kosell.kosell_session import KosellClient

logger = logging.getLogger(__name__)


class SaleProcessor:
    def __init__(
        self,
        *,
        db: Database,
        kosell: KosellClient,
        ggsel: GgselClient,
        bot: Bot,
        admin_id: int,
    ) -> None:
        self.db = db
        self.kosell = kosell
        self.ggsel = ggsel
        self.bot = bot
        self.admin_id = admin_id

    async def process_by_invoice(
        self,
        invoice_id: str,
    ) -> None:
        """
        Полный цикл обработки покупки.

        Логика определения аренды:

            GGsel sale
                ↓
            ggsel_product_id + paid_price
                ↓
            rental_variants
                ↓
            game_id + hours
                ↓
            games.kosell_product_id
                ↓
            Kosell rental

        Время аренды определяется конкретным
        rental_variant в БД.

        Важно:
        цена покупки GGsel используется как полная цена
        выбранного варианта.

        Никакого расчёта:

            paid_price - base_price

        здесь нет.
        """

        logger.info(
            "=== SALE PROCESSING START: invoice=%s ===",
            invoice_id,
        )

        # =========================================================
        # 1. Получаем продажу
        # =========================================================

        sale = await self.db.get_sale(
            invoice_id=invoice_id,
        )

        if sale is None:
            logger.error(
                "Sale not found in database: invoice=%s",
                invoice_id,
            )
            return

        logger.info(
            "sale loaded: invoice=%s sale_id=%s status=%s",
            invoice_id,
            sale["id"],
            sale["status"],
        )

        try:
            sale_id = int(
                sale["id"]
            )
        except (
            TypeError,
            ValueError,
        ):
            logger.error(
                "Invalid sale ID: invoice=%s value=%r",
                invoice_id,
                sale["id"],
            )
            return

        status = str(
            sale["status"] or "NEW"
        )

        # =========================================================
        # 2. Защита от повторной обработки
        # =========================================================

        if status in {
            "RENTING",
            "RENTED",
            "DELIVERY_PENDING",
            "COMPLETED",
        }:
            logger.info(
                "Sale already processed or processing: "
                "invoice=%s status=%s",
                invoice_id,
                status,
            )
            return

        if status == "FAILED":
            logger.warning(
                "Sale is already marked as FAILED: "
                "invoice=%s",
                invoice_id,
            )
            return

        # =========================================================
        # 3. Получаем GGsel product ID
        # =========================================================

        try:
            product_id = int(
                sale["ggsel_product_id"]
            )
        except (
            TypeError,
            ValueError,
            KeyError,
        ):
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INVALID_GGSEL_PRODUCT_ID",
                payload={
                    "value": sale.get(
                        "ggsel_product_id"
                    ),
                },
                log_message=(
                    "Invalid GGsel product ID: "
                    "invoice=%s value=%r"
                ),
                log_args=(
                    invoice_id,
                    sale.get(
                        "ggsel_product_id"
                    ),
                ),
            )
            return

        logger.info(
            "GGsel product resolved: "
            "invoice=%s product_id=%s",
            invoice_id,
            product_id,
        )

        if status != "NEW":
            raise
        try:
            message = await self._notify_admin_about_sale(
                invoice_id=invoice_id,
                sale=sale,
                product_id=product_id,
            )
        except Exception:
            logger.exception(
                "Failed to notify admin about new sale: "
                "invoice=%s",
                invoice_id,
            )
            message = None

        # =========================================================
        # 4. Находим game
        # =========================================================

        try:
            game = await self.db.get_game_by_ggsel_product(
                ggsel_product_id=product_id,
            )
        except Exception as exc:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="GAME_MAPPING_REQUEST_FAILED",
                payload={
                    "ggsel_product_id": product_id,
                    "error": str(exc),
                },
                log_message=(
                    "Failed to get game mapping: "
                    "invoice=%s product=%s error=%s"
                ),
                log_args=(
                    invoice_id,
                    product_id,
                    exc,
                ),
            )
            return

        if game is None:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="UNKNOWN_PRODUCT",
                payload={
                    "ggsel_product_id": product_id,
                },
                log_message=(
                    "No game mapping for GGsel product: "
                    "invoice=%s product=%s"
                ),
                log_args=(
                    invoice_id,
                    product_id,
                ),
            )
            return

        try:
            game_id = int(
                game["id"]
            )

            kosell_product_id = int(
                game["kosell_product_id"]
            )

        except (
            TypeError,
            ValueError,
            KeyError,
        ):
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INVALID_GAME_MAPPING",
                payload={
                    "ggsel_product_id": product_id,
                    "game": {
                        "id": game.get("id"),
                        "kosell_product_id": game.get(
                            "kosell_product_id"
                        ),
                    },
                },
                log_message=(
                    "Invalid game mapping: "
                    "invoice=%s product=%s"
                ),
                log_args=(
                    invoice_id,
                    product_id,
                ),
            )
            return

        logger.info(
            "Game mapping resolved: "
            "invoice=%s game_id=%s "
            "kosell_product=%s",
            invoice_id,
            game_id,
            kosell_product_id,
        )

        # =========================================================
        # 5. Получаем фактическую цену покупки
        # =========================================================

        try:
            paid_price = float(
                sale["price_rub"]
            )
        except (
            TypeError,
            ValueError,
            KeyError,
        ):
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INVALID_SALE_PRICE",
                payload={
                    "value": sale.get(
                        "price_rub"
                    ),
                },
                log_message=(
                    "Invalid sale price: "
                    "invoice=%s value=%r"
                ),
                log_args=(
                    invoice_id,
                    sale.get(
                        "price_rub"
                    ),
                ),
            )
            return

        if paid_price <= 0:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INVALID_SALE_PRICE",
                payload={
                    "value": paid_price,
                },
                log_message=(
                    "Sale price must be greater than zero: "
                    "invoice=%s price=%.2f"
                ),
                log_args=(
                    invoice_id,
                    paid_price,
                ),
            )
            return

        logger.info(
            "Sale price resolved: "
            "invoice=%s price=%.2f",
            invoice_id,
            paid_price,
        )
        #=======================================

        variant_price = paid_price

        logger.info(
            "Rental variant lookup: "
            "invoice=%s product=%s price=%.2f",
            invoice_id,
            product_id,
            variant_price,
        )

        try:
            rental_variant = (
                await self.db.get_rental_variant_by_price(
                    ggsel_product_id=product_id,
                    price_rub=variant_price,
                )
            )
        except Exception as exc:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="RENTAL_VARIANT_LOOKUP_FAILED",
                payload={
                    "ggsel_product_id": product_id,
                    "price_rub": variant_price,
                    "error": str(exc),
                },
                log_message=(
                    "Failed to find rental variant: "
                    "invoice=%s product=%s price=%.2f error=%s"
                ),
                log_args=(
                    invoice_id,
                    product_id,
                    variant_price,
                    exc,
                ),
            )
            return

        logger.info(
            "Rental variant resolved: "
            "invoice=%s product=%s "
            "price=%.2f variant=%s",
            invoice_id,
            product_id,
            variant_price,
            rental_variant,
        )

        if rental_variant is None:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="UNKNOWN_GGSEL_VARIANT_PRICE",
                payload={
                    "ggsel_product_id": product_id,
                    "paid_price": paid_price,
                    "variant_price": variant_price,
                },
                log_message=(
                    "No rental variant for sale price: "
                    "invoice=%s product=%s price=%.2f"
                ),
                log_args=(
                    invoice_id,
                    product_id,
                    variant_price,
                ),
            )
            return

        # =========================================================
        # 7. Проверяем соответствие game
        # =========================================================

        try:
            variant_game_id = int(
                rental_variant["game_id"]
            )
        except (
            TypeError,
            ValueError,
            KeyError,
        ):
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INVALID_RENTAL_VARIANT_GAME",
                payload={
                    "ggsel_product_id": product_id,
                    "game_id": rental_variant.get(
                        "game_id"
                    ),
                },
                log_message=(
                    "Invalid rental variant game mapping: "
                    "invoice=%s"
                ),
                log_args=(
                    invoice_id,
                ),
            )
            return

        if variant_game_id != game_id:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="RENTAL_VARIANT_GAME_MISMATCH",
                payload={
                    "ggsel_product_id": product_id,
                    "mapped_game_id": game_id,
                    "variant_game_id": variant_game_id,
                },
                log_message=(
                    "Rental variant belongs to another game: "
                    "invoice=%s product=%s "
                    "game=%s variant_game=%s"
                ),
                log_args=(
                    invoice_id,
                    product_id,
                    game_id,
                    variant_game_id,
                ),
            )
            return

        # =========================================================
        # 8. Получаем часы из rental_variants
        # =========================================================

        try:
            duration_hours = int(
                rental_variant["hours"]
            )
        except (
            TypeError,
            ValueError,
            KeyError,
        ):
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INVALID_RENTAL_VARIANT_HOURS",
                payload={
                    "ggsel_product_id": product_id,
                    "hours": rental_variant.get(
                        "hours"
                    ),
                },
                log_message=(
                    "Invalid rental variant hours: "
                    "invoice=%s product=%s hours=%r"
                ),
                log_args=(
                    invoice_id,
                    product_id,
                    rental_variant.get(
                        "hours"
                    ),
                ),
            )
            return

        if duration_hours <= 0:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INVALID_RENTAL_VARIANT_HOURS",
                payload={
                    "ggsel_product_id": product_id,
                    "hours": duration_hours,
                },
                log_message=(
                    "Rental variant contains invalid duration: "
                    "invoice=%s hours=%s"
                ),
                log_args=(
                    invoice_id,
                    duration_hours,
                ),
            )
            return

        logger.info(
            "Rental duration determined: "
            "invoice=%s product=%s "
            "price=%.2f hours=%s "
            "variant_id=%s",
            invoice_id,
            product_id,
            paid_price,
            duration_hours,
            rental_variant.get(
                "ggsel_variant_id"
            ),
        )

        # =========================================================
        # 9. Сохраняем game в sale
        # =========================================================

        try:
            await self.db.set_sale_game(
                invoice_id=invoice_id,
                game_id=game_id,
            )
        except Exception as exc:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="SALE_GAME_SAVE_FAILED",
                payload={
                    "game_id": game_id,
                    "error": str(exc),
                },
                log_message=(
                    "Failed to save game to sale: "
                    "invoice=%s game=%s error=%s"
                ),
                log_args=(
                    invoice_id,
                    game_id,
                    exc,
                ),
            )
            return

        # =========================================================
        # 10. Переводим sale в RENTING
        # =========================================================

        try:
            await self.db.set_sale_status(
                invoice_id=invoice_id,
                status="RENTING",
            )

            await self.db.add_event(
                event_type="RENTING_STARTED",
                sale_id=sale_id,
                payload={
                    "ggsel_product_id": product_id,
                    "game_id": game_id,
                    "kosell_product_id": kosell_product_id,
                    "duration_hours": duration_hours,
                    "ggsel_variant_id": rental_variant.get(
                        "ggsel_variant_id"
                    ),
                    "paid_price": paid_price,
                },
            )
        except Exception as exc:
            logger.exception(
                "Failed to mark sale as RENTING: "
                "invoice=%s error=%s",
                invoice_id,
                exc,
            )
            return

        logger.info(
            "Rental processing started: "
            "invoice=%s kosell_product=%s hours=%s",
            invoice_id,
            kosell_product_id,
            duration_hours,
        )

        # =========================================================
        # 11. Рассчитываем стоимость Kosell
        # =========================================================

        try:
            price = await self.kosell.calculate_price(
                product_id=kosell_product_id,
                hours=duration_hours,
            )

        except Exception as exc:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="KOSSELL_PRICE_REQUEST_FAILED",
                payload={
                    "kosell_product_id": kosell_product_id,
                    "duration_hours": duration_hours,
                    "error": str(exc),
                },
                log_message=(
                    "Failed to calculate Kosell rental price: "
                    "invoice=%s error=%s"
                ),
                log_args=(
                    invoice_id,
                    exc,
                ),
            )
            return

        rental_cost = self._extract_cost(
            price
        )

        if rental_cost is None:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="RENTAL_PRICE_UNKNOWN",
                payload={
                    "kosell_product_id": kosell_product_id,
                    "duration_hours": duration_hours,
                    "price_response": self._safe_payload(
                        price
                    ),
                },
                log_message=(
                    "Kosell returned an unusable "
                    "rental price: invoice=%s"
                ),
                log_args=(
                    invoice_id,
                ),
            )
            return

        if rental_cost < 0:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INVALID_RENTAL_PRICE",
                payload={
                    "kosell_product_id": kosell_product_id,
                    "duration_hours": duration_hours,
                    "rental_cost": rental_cost,
                },
                log_message=(
                    "Kosell returned negative rental price: "
                    "invoice=%s rental_cost=%.2f"
                ),
                log_args=(
                    invoice_id,
                    rental_cost,
                ),
            )
            return

        logger.info(
            "Kosell rental price determined: "
            "invoice=%s rental_cost=%.2f",
            invoice_id,
            rental_cost,
        )

        # =========================================================
        # 13. Проверяем баланс Kosell
        # =========================================================

        try:
            balance_response = (
                await self.kosell.get_balance()
            )

        except Exception as exc:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="KOSSELL_BALANCE_REQUEST_FAILED",
                payload={
                    "error": str(exc),
                },
                log_message=(
                    "Failed to get Kosell balance: "
                    "invoice=%s error=%s"
                ),
                log_args=(
                    invoice_id,
                    exc,
                ),
            )
            return

        balance_rub = balance_response.get(
            "balance_rub"
        )

        if isinstance(
            balance_rub,
            str,
        ):
            try:
                balance_rub = float(
                    balance_rub
                )
            except ValueError:
                balance_rub = None

        if not isinstance(
            balance_rub,
            (int, float),
        ):
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="KOSSELL_BALANCE_UNKNOWN",
                payload={
                    "balance_response": self._safe_payload(
                        balance_response
                    ),
                },
                log_message=(
                    "Cannot determine Kosell balance: "
                    "invoice=%s"
                ),
                log_args=(
                    invoice_id,
                ),
            )
            return

        balance_rub = float(
            balance_rub
        )

        logger.info(
            "Kosell balance check: "
            "invoice=%s balance=%.2f "
            "required=%.2f",
            invoice_id,
            balance_rub,
            rental_cost,
        )

        if balance_rub < rental_cost:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="INSUFFICIENT_KOSSELL_BALANCE",
                payload={
                    "rental_cost": rental_cost,
                    "balance_rub": balance_rub,
                    "missing": rental_cost - balance_rub,
                },
                log_message=(
                    "Insufficient Kosell balance: "
                    "invoice=%s balance=%.2f "
                    "required=%.2f"
                ),
                log_args=(
                    invoice_id,
                    balance_rub,
                    rental_cost,
                ),
            )
            return

        # =========================================================
        # 14. Создаём аренду в Kosell
        # =========================================================

        logger.info(
            "Creating Kosell rental: "
            "invoice=%s product=%s duration=%sh",
            invoice_id,
            kosell_product_id,
            duration_hours,
        )

        try:
            rental = await self.kosell.rent(
                product_id=kosell_product_id,
                duration_hours=duration_hours,
            )

        except httpx.HTTPStatusError as e:
            try:
                error_data = e.response.json()
            except ValueError:
                error_data = {"detail": e.response.text[:2000]}

            detail = error_data.get("detail")

            if isinstance(detail, dict):
                error_message = detail.get("message") or str(detail)
            else:
                error_message = str(detail or error_data)

            # sqlite3.Row нельзя отправлять в Telegram HTML напрямую.
            # Преобразуем его в обычный dict.
            sale_data = dict(sale) if hasattr(sale, "keys") else sale

            text = (
                "<b>Не удалось взять в аренду аккаунт</b>\n"
                f"Ошибка Kosell: <code>{escape(str(error_message))}</code>\n"
                f"Игра: <code>{escape(str(game.get('name', '—')))}</code>\n"
                f"invoice_id: <code>{escape(str(invoice_id))}</code>\n"
                f"sale_id: <code>{escape(str(sale_id))}</code>\n"
                f"duration_hours: <code>{escape(str(duration_hours))}</code>\n"
                f"sale: <code>{escape(str(sale_data))}</code>"
            )

            try:
                await self.bot.send_message(
                    self.admin_id,
                    text,
                    parse_mode="HTML",
                )
            except Exception:
                logger.exception("Failed to send Kosell error to admin")

            await self.ggsel.send_message(
                debate_id=int(invoice_id),
                message=(
                    "Спасибо за покупку!\n\n"
                    "В скором времени менеджер свяжется с вами "
                    "для выдачи аккаунта (до 2 часов)"
                ),
            )

            logger.error(
                "Kosell rental failed: status=%s response=%r",
                e.response.status_code,
                error_data,
            )

            return

        except Exception as exc:
            payload = {
                "kosell_product_id": kosell_product_id,
                "duration_hours": duration_hours,
                "error": str(exc),
            },
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="RENTAL_REQUEST_FAILED",
                payload=payload,
                log_message=(
                    "Kosell rental request failed: "
                    "invoice=%s error=%s"
                ),
                log_args=(
                    invoice_id,
                    exc,
                ),
            )

            await self.bot.send_message(
                self.admin_id,
                f"Произошла ошибка, {exc}, {invoice_id=}, {sale_id=}, {payload=}"
            )
            return

        # =========================================================
        # 15. Получаем rental UID
        # =========================================================

        rental_uid = self._extract_rental_uid(
            rental
        )

        if rental_uid is None:
            await self._fail(
                invoice_id=invoice_id,
                sale_id=sale_id,
                event_type="RENTAL_UID_MISSING",
                payload={
                    "kosell_product_id": kosell_product_id,
                    "duration_hours": duration_hours,
                    "rental_response": self._safe_payload(
                        rental
                    ),
                },
                log_message=(
                    "Kosell rental created but UID "
                    "was not returned: invoice=%s"
                ),
                log_args=(
                    invoice_id,
                ),
            )
            return

        logger.info(
            "Kosell rental created: "
            "invoice=%s rental_uid=%s",
            invoice_id,
            rental_uid,
        )

        # =========================================================
        # 16. Сохраняем rental в БД
        # =========================================================

        try:
            await self.db.create_rental(
                invoice_id=int(invoice_id),
                sale_id=sale_id,
                game_id=game_id,
                rental_uid=rental_uid,
                duration_hours=duration_hours,
                cost=rental_cost,
            )

        except Exception as exc:
            # ВАЖНО:
            #
            # rental уже существует в Kosell.
            # Повторный rent() здесь делать НЕЛЬЗЯ.
            #
            # Оставляем продажу в DELIVERY_PENDING,
            # чтобы её можно было обработать вручную/отдельным
            # recovery-механизмом.

            try:
                await self.db.set_sale_status(
                    invoice_id=invoice_id,
                    status="DELIVERY_PENDING",
                )

                await self.db.add_event(
                    event_type="RENTAL_DB_SAVE_FAILED",
                    sale_id=sale_id,
                    payload={
                        "rental_uid": rental_uid,
                        "duration_hours": duration_hours,
                        "error": str(exc),
                    },
                )
            except Exception:
                logger.exception(
                    "Failed to save recovery state after "
                    "rental DB save failure: invoice=%s",
                    invoice_id,
                )

            logger.exception(
                "CRITICAL: rental exists in Kosell "
                "but could not be saved in DB: "
                "invoice=%s rental_uid=%s",
                invoice_id,
                rental_uid,
            )

            return

        await self.db.add_event(
            event_type="RENTAL_CREATED",
            sale_id=sale_id,
            payload={
                "kosell_product_id": kosell_product_id,
                "duration_hours": duration_hours,
                "cost": rental_cost,
            },
        )

        logger.info(
            "Rental saved in database: "
            "invoice=%s duration=%sh",
            invoice_id,
            duration_hours,
        )

        # =========================================================
        # 17. Получаем credentials
        # =========================================================

        logger.info(
            "Requesting rental credentials: "
            "invoice=%s",
            invoice_id,
        )

        try:
            credentials = (
                await self.kosell.get_credentials(
                    rental_uid=rental_uid,
                )
            )

        except Exception as exc:
            try:
                await self.db.set_sale_status(
                    invoice_id=invoice_id,
                    status="DELIVERY_PENDING",
                )

                await self.db.add_event(
                    event_type="CREDENTIALS_REQUEST_FAILED",
                    sale_id=sale_id,
                    payload={
                        "error": str(exc),
                    },
                )
            except Exception:
                logger.exception(
                    "Failed to save credentials recovery state: "
                    "invoice=%s",
                    invoice_id,
                )

            logger.exception(
                "Failed to get rental credentials: "
                "invoice=%s",
                invoice_id,
            )

            return

        # =========================================================
        # 18. Проверяем credentials
        # =========================================================

        login = credentials.get(
            "steam_login"
        )

        password = credentials.get(
            "steam_password"
        )

        if not isinstance(
            login,
            str,
        ) or not login:
            await self.db.set_sale_status(
                invoice_id=invoice_id,
                status="DELIVERY_PENDING",
            )

            await self.db.add_event(
                event_type="STEAM_LOGIN_MISSING",
                sale_id=sale_id,
            )

            logger.error(
                "Kosell credentials do not contain "
                "steam_login: invoice=%s",
                invoice_id,
            )

            return

        if not isinstance(
            password,
            str,
        ) or not password:
            await self.db.set_sale_status(
                invoice_id=invoice_id,
                status="DELIVERY_PENDING",
            )

            await self.db.add_event(
                event_type="STEAM_PASSWORD_MISSING",
                sale_id=sale_id,
            )

            logger.error(
                "Kosell credentials do not contain "
                "steam_password: invoice=%s",
                invoice_id,
            )

            return

        await self.db.add_event(
            event_type="CREDENTIALS_RECEIVED",
            sale_id=sale_id,
        )

        logger.info(
            "Rental credentials received: "
            "invoice=%s",
            invoice_id,
        )

        # =========================================================
        # 19. Отправляем credentials покупателю
        # =========================================================

        logger.info(
            "Sending credentials to GGsel buyer: "
            "invoice=%s",
            invoice_id,
        )

        try:
            await self.ggsel.send_message(
                debate_id=int(invoice_id),
                message=(
                    "Спасибо за покупку!\n\n"
                    f"Login: {login}\n"
                    f"Password: {password}\n\n"
                    "💡 Если требуется Steam Guard, "
                    "напишите слово: код\n💡 If Steam Guard is required, type the word: code"
                ),
            )

        except Exception as exc:
            await self.db.set_sale_status(
                invoice_id=invoice_id,
                status="DELIVERY_PENDING",
            )

            await self.db.add_event(
                event_type="CREDENTIALS_DELIVERY_FAILED",
                sale_id=sale_id,
                payload={
                    "error": str(exc),
                },
            )

            logger.exception(
                "Failed to deliver credentials "
                "to GGsel buyer: invoice=%s",
                invoice_id,
            )

            return

        # =========================================================
        # 20. Успешная доставка
        # =========================================================

        await self.db.add_event(
            event_type="CREDENTIALS_DELIVERED",
            sale_id=sale_id,
        )

        await self.db.set_sale_status(
            invoice_id=invoice_id,
            status="COMPLETED",
        )
        try:
            price_rub = float(
                sale["price_rub"]
            )
        except (
                TypeError,
                ValueError,
                KeyError,
        ):
            price_rub = 0.0
        if isinstance(message, Message):
            await message.edit_text(text=(
                    "Новая продажа\n\n"
                    f"Номер заказа: <code>{invoice_id}</code>\n"
                    f"GGsel product: <code>{product_id}</code>\n"
                    f"Сумма: <b>{price_rub:.2f} ₽</b>\n"
                    "Статус: <b>#COMPLITED</b>"
                )
            )

        logger.info(
            "=== SALE COMPLETED: invoice=%s ===",
            invoice_id,
        )

    async def _fail(
        self,
        *,
        invoice_id: str,
        sale_id: int,
        event_type: str,
        payload: dict[str, Any] | None,
        log_message: str,
        log_args: tuple[Any, ...],
    ) -> None:
        """
        Единая обработка ожидаемой бизнес-ошибки.

        Не содержит credentials и другие секреты.
        """

        try:
            await self.db.set_sale_status(
                invoice_id=invoice_id,
                status="FAILED",
            )

            await self.db.add_event(
                event_type=event_type,
                sale_id=sale_id,
                payload=payload,
            )
        except Exception:
            logger.exception(
                "Failed to persist failure state: "
                "invoice=%s event_type=%s",
                invoice_id,
                event_type,
            )

        logger.error(
            log_message,
            *log_args,
        )

    @staticmethod
    def _safe_payload(
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Возвращает только безопасную диагностическую
        часть API-ответа.

        Не сохраняем потенциальные credentials,
        токены и другие секреты.
        """

        sensitive_keys = {
            "steam_login",
            "steam_password",
            "login",
            "password",
            "credentials",
            "token",
            "api_key",
            "code",
            "steam_guard_code",
        }

        safe_payload: dict[str, Any] = {}

        for key, value in payload.items():
            normalized_key = str(
                key
            ).lower()

            if normalized_key in sensitive_keys:
                continue

            safe_payload[str(key)] = value

        return safe_payload

    @staticmethod
    def _extract_rental_uid(
        payload: dict[str, Any],
    ) -> str | None:
        """
        Извлекает UID созданной аренды из ответа Kosell.
        """

        for key in (
            "rental_uid",
            "uid",
            "rental_id",
        ):
            value = payload.get(
                key
            )

            if value is not None:
                value = str(
                    value
                ).strip()

                if value:
                    return value

        return None

    @staticmethod
    def _extract_cost(
        payload: dict[str, Any],
    ) -> float | None:
        """
        Извлекает стоимость аренды из ответа Kosell.
        """

        for key in (
            "total_rub",
            "price",
            "cost",
            "total",
            "amount",
        ):
            value = payload.get(
                key
            )

            if isinstance(
                value,
                (int, float),
            ):
                return float(
                    value
                )

            if isinstance(
                value,
                str,
            ):
                try:
                    return float(
                        value
                    )
                except ValueError:
                    continue

        return None

    async def _notify_admin_about_sale(
            self,
            *,
            invoice_id: str,
            sale: Any,
            product_id: int,
    ) -> Message:
        try:
            price_rub = float(
                sale["price_rub"]
            )
        except (
                TypeError,
                ValueError,
                KeyError,
        ):
            price_rub = 0.0

        return await self.bot.send_message(
            chat_id=self.admin_id,
            text=(
                "Новая продажа\n\n"
                f"Номер заказа: <code>{invoice_id}</code>\n"
                f"GGsel product: <code>{product_id}</code>\n"
                f"Сумма: <b>{price_rub:.2f} ₽</b>\n"
                "Статус: <b>#PENDING</b>"
            ),
            parse_mode="HTML",
        )