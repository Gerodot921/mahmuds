import asyncio
import logging

from aiogram import Bot

from db import Database
from ggsel.ggsel_session import GgselClient
from kosell.kosell_session import KosellClient


logger = logging.getLogger(__name__)


async def check_no_account_loop(
    ggsel: GgselClient,
    kosell: KosellClient,
    db: Database,
    bot: Bot,
):
    while True:
        try:
            logger.info("Проверяем на отсутствие аккаунта и удаляем.")
            await check_no_account(
                ggsel=ggsel,
                kosell=kosell,
                db=db,
                bot=bot,
            )
        except Exception:
            logger.exception("Ошибка при проверке товаров GGsel/Kosell")

        await asyncio.sleep(5 * 60)  # Каждые 5 минут.

async def check_no_account(
    ggsel: GgselClient,
    kosell: KosellClient,
    db: Database,
    bot: Bot
):
    my_sells = await ggsel.get_my_sells()

    # Названия игр GGsel из нашей БД.
    # ВАЖНО: берем все товары, включая visible == 0,
    # чтобы иметь возможность повторно активировать их.
    ggsel_game_names: dict[int, str] = {}

    for product in my_sells:
        product_id = product.get("id_goods")

        if product_id is None:
            continue

        try:
            product_id = int(product_id)
        except (TypeError, ValueError):
            continue

        game = await db.get_game_by_ggsel_product(
            ggsel_product_id=product_id,
        )

        if game is not None:
            ggsel_game_names[product_id] = game["name"]

    logger.info(f"MY GAMES GGSEL: {ggsel_game_names=}")

    # Получаем ВСЕ товары Kosell, включая товары с 0 доступных аккаунтов.
    kosell_sells = [
        {
            "name": x.get("name"),
            "available": x.get("available_accounts", 0),
        }
        for x in await kosell.get_rental_products()
        if x.get("name")
    ]

    kosell_by_name = {
        sell["name"]: sell["available"]
        for sell in kosell_sells
    }

    products_to_hide = []
    products_to_show = []

    for product in my_sells:
        product_id = product.get("id_goods")

        if product_id is None:
            continue

        try:
            product_id = int(product_id)
        except (TypeError, ValueError):
            continue

        game_name = ggsel_game_names.get(product_id)

        if not game_name:
            continue

        product["game_name"] = game_name

        # Текущий статус товара на GGsel.
        is_visible = bool(product.get("visible"))

        # Игры нет на Kosell -> доступных аккаунтов нет.
        if game_name not in kosell_by_name:
            if is_visible:
                products_to_hide.append(product)

            continue

        # Игра есть на Kosell -> проверяем количество аккаунтов.
        try:
            available = int(kosell_by_name[game_name] or 0)
        except (TypeError, ValueError):
            available = 0

        if available <= 0:
            # Нет аккаунтов -> товар должен быть скрыт.
            if is_visible:
                products_to_hide.append(product)

        else:
            # Есть аккаунты -> товар должен быть активен.
            if not is_visible:
                products_to_show.append(product)

    logger.info(
        "GGsel sync: hide=%d, show=%d",
        len(products_to_hide),
        len(products_to_show),
    )

    if products_to_hide:
        await ggsel.hide_products(
            products_to_hide,
            bot=bot,
        )

    if products_to_show:
        await ggsel.show_products(
            products_to_show,
            bot=bot,
        )

    return {
        "hidden": products_to_hide,
        "shown": products_to_show,
    }


# if __name__ == "__main__":
#     logging.basicConfig(level=logging.DEBUG)
#     ggel = GgselClient()
#     kosell = KosellClient()
#     asyncio.run(check_no_account())