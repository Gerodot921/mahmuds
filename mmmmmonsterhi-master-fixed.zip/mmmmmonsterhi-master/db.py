from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import aiosqlite


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    kosell_product_id INTEGER NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS offers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ggsel_product_id INTEGER NOT NULL UNIQUE,
    game_id INTEGER NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,

    FOREIGN KEY (game_id)
        REFERENCES games(id)
        ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    invoice_id TEXT NOT NULL UNIQUE,

    ggsel_product_id INTEGER NOT NULL,

    game_id INTEGER,

    product_name TEXT NOT NULL DEFAULT '',

    price_rub REAL NOT NULL,

    sale_date TEXT,

    status TEXT NOT NULL DEFAULT 'NEW',

    raw_data TEXT NOT NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    processed_at TEXT,

    FOREIGN KEY (game_id)
        REFERENCES games(id)
        ON DELETE SET NULL
);


CREATE TABLE IF NOT EXISTS rentals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    sale_id INTEGER NOT NULL UNIQUE,

    game_id INTEGER NOT NULL,

    kosell_rental_uid TEXT NOT NULL UNIQUE,

    status TEXT NOT NULL DEFAULT 'ACTIVE',

    cost REAL,

    duration_hours INTEGER NOT NULL,
    
    invoice_id INTEGER NOT NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    expires_at TEXT,

    FOREIGN KEY (sale_id)
        REFERENCES sales(id)
        ON DELETE CASCADE,

    FOREIGN KEY (game_id)
        REFERENCES games(id)
        ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    sale_id INTEGER,

    type TEXT NOT NULL,

    payload TEXT,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (sale_id)
        REFERENCES sales(id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS rental_variants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    game_id INTEGER NOT NULL,

    ggsel_product_id INTEGER NOT NULL,

    ggsel_variant_id INTEGER NOT NULL,

    hours INTEGER,

    price_rub REAL NOT NULL,

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (game_id)
        REFERENCES games(id)
        ON DELETE CASCADE,

    UNIQUE (
        ggsel_product_id,
        ggsel_variant_id
    )
);

CREATE INDEX IF NOT EXISTS
idx_rental_variants_ggsel_product
ON rental_variants (
    ggsel_product_id
);

CREATE INDEX IF NOT EXISTS
idx_rental_variants_ggsel_variant
ON rental_variants (
    ggsel_variant_id
);

CREATE INDEX IF NOT EXISTS idx_sales_status
ON sales(status);

CREATE INDEX IF NOT EXISTS idx_sales_product
ON sales(ggsel_product_id);

CREATE INDEX IF NOT EXISTS idx_rentals_status
ON rentals(status);

"""


class Database:
    def __init__(
        self,
        path: str | Path,
    ) -> None:
        self.path = Path(path)
        self.connection: aiosqlite.Connection | None = None

    async def connect(self) -> None:
        self.path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        self.connection = await aiosqlite.connect(
            self.path,
        )

        self.connection.row_factory = aiosqlite.Row

        await self.connection.executescript(SCHEMA)
        await self.connection.commit()

    async def close(self) -> None:
        if self.connection:
            await self.connection.close()

        self.connection = None

    def _db(self) -> aiosqlite.Connection:
        if self.connection is None:
            raise RuntimeError(
                "Database is not connected"
            )

        return self.connection

    async def insert_webhook_sale(
            self,
            *,
            invoice_id: str,
            ggsel_product_id: int,
            amount: float,
            currency: str,
            sale_date: str | None,
            raw_data: dict[str, Any],
    ) -> bool:
        cursor = await self._db().execute(
            """
            INSERT INTO sales (invoice_id,
                               ggsel_product_id,
                               product_name,
                               price_rub,
                               sale_date,
                               raw_data,
                               status)
            VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(invoice_id) DO NOTHING
            """,
            (
                invoice_id,
                ggsel_product_id,
                "",
                amount,
                sale_date,
                json.dumps(
                    raw_data,
                    ensure_ascii=False,
                ),
                "NEW",
            ),
        )

        await self._db().commit()

        return cursor.rowcount == 1


    async def create_game(
            self,
            *,
            name: str,
            kosell_product_id: int,
    ) -> int:
        cursor = await self._db().execute(
            """
            INSERT INTO games (name,
                               kosell_product_id)
            VALUES (?, ?)
            """,
            (
                name,
                kosell_product_id,
            ),
        )

        await self._db().commit()

        return int(cursor.lastrowid)

    async def create_offer_mapping(
        self,
        *,
        ggsel_product_id: int,
        game_id: int,
    ) -> None:
        await self._db().execute(
            """
            INSERT INTO offers (
                ggsel_product_id,
                game_id
            )
            VALUES (?, ?)
            """,
            (
                ggsel_product_id,
                game_id,
            ),
        )

        await self._db().commit()

    async def get_game_by_ggsel_product(
            self,
            *,
            ggsel_product_id: int,
    ):
        cursor = await self._db().execute(
            """
            SELECT g.id,
                   g.name,
                   g.kosell_product_id,
                   g.enabled
            FROM games g
                     INNER JOIN offers o
                                ON o.game_id = g.id
            WHERE o.ggsel_product_id = ? LIMIT 1
            """,
            (ggsel_product_id,),
        )

        row = await cursor.fetchone()

        if row is None:
            return None

        return {
            "id": row[0],
            "name": row[1],
            "kosell_product_id": row[2],
            "enabled": row[3],
        }

    async def insert_sale_if_new(
        self,
        *,
        invoice_id: str,
        ggsel_product_id: int,
        product_name: str,
        price_rub: float,
        sale_date: str | None,
        raw_data: dict[str, Any],
    ) -> bool:
        cursor = await self._db().execute(
            """
            INSERT OR IGNORE INTO sales (
                invoice_id,
                ggsel_product_id,
                product_name,
                price_rub,
                sale_date,
                raw_data
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                invoice_id,
                ggsel_product_id,
                product_name,
                price_rub,
                sale_date,
                json.dumps(
                    raw_data,
                    ensure_ascii=False,
                ),
            ),
        )

        await self._db().commit()

        return cursor.rowcount == 1

    async def get_sale(
        self,
        *,
        invoice_id: str,
    ) -> aiosqlite.Row | None:
        cursor = await self._db().execute(
            """
            SELECT *
            FROM sales
            WHERE invoice_id = ?
            """,
            (invoice_id,),
        )

        return await cursor.fetchone()

    async def set_sale_game(
        self,
        *,
        invoice_id: str,
        game_id: int,
    ) -> None:
        await self._db().execute(
            """
            UPDATE sales
            SET game_id = ?
            WHERE invoice_id = ?
            """,
            (
                game_id,
                invoice_id,
            ),
        )

        await self._db().commit()

    async def set_sale_status(
        self,
        *,
        invoice_id: str,
        status: str,
    ) -> None:
        await self._db().execute(
            """
            UPDATE sales
            SET
                status = ?,
                processed_at = CASE
                    WHEN ? IN ('COMPLETED', 'FAILED')
                    THEN CURRENT_TIMESTAMP
                    ELSE processed_at
                END
            WHERE invoice_id = ?
            """,
            (
                status,
                status,
                invoice_id,
            ),
        )

        await self._db().commit()

    async def create_rental(
        self,
        *,
        sale_id: int,
        game_id: int,
        rental_uid: str,
        invoice_id: int,
        duration_hours: int,
        cost: float | None = None,
        expires_at: str | None = None,
    ) -> int:
        cursor = await self._db().execute(
            """
            INSERT INTO rentals (
                sale_id,
                game_id,
                kosell_rental_uid,
                duration_hours,
                invoice_id,
                cost,
                expires_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                sale_id,
                game_id,
                rental_uid,
                duration_hours,
                invoice_id,
                cost,
                expires_at,
            ),
        )

        await self._db().commit()

        return int(cursor.lastrowid)

    async def get_rental_by_invoice_id(
            self,
            invoice_id: int,
    ) -> dict[str, Any] | None:
        cursor = await self._db().execute(
            """
            SELECT id,
                   sale_id,
                   game_id,
                   kosell_rental_uid,
                   duration_hours,
                   invoice_id,
                   cost,
                   expires_at
            FROM rentals
            WHERE invoice_id = ? LIMIT 1
            """,
            (invoice_id,),
        )

        row = await cursor.fetchone()

        if row is None:
            return None

        columns = [
            "id",
            "sale_id",
            "game_id",
            "kosell_rental_uid",
            "duration_hours",
            "invoice_id",
            "cost",
            "expires_at",
        ]

        return dict(zip(columns, row))

    async def add_event(
        self,
        *,
        event_type: str,
        sale_id: int | None = None,
        payload: dict[str, Any] | None = None,
    ) -> None:
        await self._db().execute(
            """
            INSERT INTO events (
                sale_id,
                type,
                payload
            )
            VALUES (?, ?, ?)
            """,
            (
                sale_id,
                event_type,
                json.dumps(
                    payload,
                    ensure_ascii=False,
                )
                if payload is not None
                else None,
            ),
        )

        await self._db().commit()

    async def create_rental_variant(
            self,
            *,
            game_id: int,
            ggsel_product_id: int,
            ggsel_variant_id: int | None,
            hours: int,
            price_rub: float,
    ) -> int:
        cursor = await self.connection.execute(
            """
            INSERT INTO rental_variants (game_id,
                                         ggsel_product_id,
                                         ggsel_variant_id,
                                         hours,
                                         price_rub)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                game_id,
                ggsel_product_id,
                ggsel_variant_id,
                hours,
                price_rub,
            ),
        )

        await self.connection.commit()

        return int(cursor.lastrowid)

    async def get_rental_variants(
            self,
            *,
            ggsel_product_id: int,
    ) -> list[dict[str, Any]]:
        cursor = await self.connection.execute(
            """
            SELECT id,
                   game_id,
                   ggsel_product_id,
                   ggsel_variant_id,
                   hours,
                   price_rub,
                   created_at
            FROM rental_variants
            WHERE ggsel_product_id = ?
            ORDER BY hours ASC
            """,
            (ggsel_product_id,),
        )

        rows = await cursor.fetchall()

        return [
            dict(row)
            for row in rows
        ]

    async def get_rental_variant_by_hours(
            self,
            *,
            ggsel_product_id: int,
            hours: int,
    ) -> dict[str, Any] | None:
        cursor = await self.connection.execute(
            """
            SELECT id,
                   game_id,
                   ggsel_product_id,
                   ggsel_variant_id,
                   hours,
                   price_rub,
                   created_at
            FROM rental_variants
            WHERE ggsel_product_id = ?
              AND hours = ? LIMIT 1
            """,
            (
                ggsel_product_id,
                hours,
            ),
        )

        row = await cursor.fetchone()

        if row is None:
            return None

        return dict(row)

    async def upsert_rental_variant(
            self,
            *,
            game_id: int,
            ggsel_product_id: int,
            ggsel_variant_id: int,
            hours: int | None,
            price_rub: float,
    ) -> None:
        await self._db().execute(
            """
            INSERT INTO rental_variants (game_id,
                                         ggsel_product_id,
                                         ggsel_variant_id,
                                         hours,
                                         price_rub)
            VALUES (?, ?, ?, ?, ?) ON CONFLICT (
                ggsel_product_id,
                ggsel_variant_id
            )
            DO
            UPDATE SET
                game_id = excluded.game_id,
                hours = excluded.hours,
                price_rub = excluded.price_rub
            """,
            (
                game_id,
                ggsel_product_id,
                ggsel_variant_id,
                hours,
                price_rub,
            ),
        )

        await self._db().commit()

    async def get_rental_variant_by_ggsel_variant(
            self,
            *,
            ggsel_product_id: int,
            ggsel_variant_id: int,
    ) -> dict[str, Any] | None:
        cursor = await self._db().execute(
            """
            SELECT id,
                   game_id,
                   ggsel_product_id,
                   ggsel_variant_id,
                   hours,
                   price_rub,
                   created_at
            FROM rental_variants
            WHERE ggsel_product_id = ?
              AND ggsel_variant_id = ? LIMIT 1
            """,
            (
                ggsel_product_id,
                ggsel_variant_id,
            ),
        )

        row = await cursor.fetchone()

        if row is None:
            return None

        return dict(row)

    async def create_game_with_offer(
            self,
            *,
            name: str,
            kosell_product_id: int,
            ggsel_product_id: int,
    ) -> int:
        db = self._db()

        try:
            await db.execute("BEGIN")

            cursor = await db.execute(
                """
                INSERT INTO games (name,
                                   kosell_product_id)
                VALUES (?, ?)
                """,
                (
                    name,
                    kosell_product_id,
                ),
            )

            game_id = int(cursor.lastrowid)

            await db.execute(
                """
                INSERT INTO offers (ggsel_product_id,
                                    game_id)
                VALUES (?, ?)
                """,
                (
                    ggsel_product_id,
                    game_id,
                ),
            )

            await db.commit()

            return game_id

        except Exception:
            await db.rollback()
            raise


    async def get_rental_variant_by_price(
            self,
            *,
            ggsel_product_id: int,
            price_rub: float,
    ) -> dict[str, Any] | None:
        cursor = await self._db().execute(
            """
            SELECT id,
                   game_id,
                   ggsel_product_id,
                   ggsel_variant_id,
                   hours,
                   price_rub,
                   created_at
            FROM rental_variants
            WHERE ggsel_product_id = ?
              AND price_rub = ?
            ORDER BY id ASC LIMIT 1
            """,
            (
                ggsel_product_id,
                price_rub,
            ),
        )

        row = await cursor.fetchone()

        if row is None:
            return None

        return dict(row)

    async def set_rental_variant_hours(
            self,
            *,
            game_id: int,
            ggsel_product_id: int,
            ggsel_variant_id: int,
            price_rub: float,
            hours: int,
    ) -> None:
        if hours <= 0:
            raise ValueError(
                "Количество часов должно быть больше нуля"
            )

        await self._db().execute(
            """
            INSERT INTO rental_variants (game_id,
                                         ggsel_product_id,
                                         ggsel_variant_id,
                                         hours,
                                         price_rub)
            VALUES (?, ?, ?, ?, ?) ON CONFLICT (
                ggsel_product_id,
                ggsel_variant_id
            )
            DO
            UPDATE SET
                game_id = excluded.game_id,
                hours = excluded.hours,
                price_rub = excluded.price_rub
            """,
            (
                game_id,
                ggsel_product_id,
                ggsel_variant_id,
                hours,
                price_rub,
            ),
        )

        await self._db().commit()