from __future__ import annotations

import logging
import os
from decimal import Decimal, InvalidOperation
from typing import Any

from aiogram import Dispatcher, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from db import Database
from ggsel.ggsel_session import GgselClient
from kosell.kosell_session import KosellClient


logger = logging.getLogger(__name__)


# ============================================================
# CONFIG
# ============================================================

TG_ADMIN_IDS: set[int] = {
    int(value.strip())
    for value in os.getenv(
        "TELEGRAM_ADMIN_ID",
        "",
    ).split(",")
    if value.strip().isdigit()
}

MAX_VARIANTS = 1
MAX_OPTIONS = 5

MAX_TITLE_LENGTH = 255
MAX_PRICE = Decimal("10000000")
MAX_HOURS = 24 * 365


# ============================================================
# FSM
# ============================================================


class MappingStates(StatesGroup):
    waiting_ggsel_id = State()
    waiting_kosell_product_id = State()


class VariantStates(StatesGroup):
    """
    Создание пользовательского Variant.

    Пользовательский Variant =
    GGsel Option-контейнер.
    """

    waiting_title_ru = State()
    waiting_title_en = State()


class OptionStates(StatesGroup):
    """
    Создание пользовательского Option.

    Пользовательский Option =
    GGsel Variant.

    Также используется для редактирования.
    """

    waiting_title_ru = State()
    waiting_title_en = State()
    waiting_price = State()
    waiting_hours = State()
    editing_hours = State()


# ============================================================
# BOT
# ============================================================


class GgselBot:

    def __init__(
        self,
        *,
        ggsel: GgselClient,
        kosell: KosellClient,
        db: Database,
    ) -> None:
        self.ggsel = ggsel
        self.kosell = kosell
        self.db = db

    # ========================================================
    # AUTH
    # ========================================================

    @staticmethod
    def is_admin(
        user_id: int | None,
    ) -> bool:
        return (
            user_id is not None
            and user_id in TG_ADMIN_IDS
        )

    # ========================================================
    # PARSERS
    # ========================================================

    @staticmethod
    def parse_positive_int(
        value: str,
        field_name: str,
    ) -> int:
        value = value.strip()

        if not value.isdigit():
            raise ValueError(
                f"{field_name} должен быть целым числом."
            )

        result = int(value)

        if result <= 0:
            raise ValueError(
                f"{field_name} должен быть положительным."
            )

        return result

    async def start_edit_option_hours(
            self,
            callback: CallbackQuery,
            state: FSMContext,
    ) -> None:
        if not self.is_admin(
                callback.from_user.id
                if callback.from_user
                else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        parts = (callback.data or "").split(":")

        if (
                len(parts) != 5
                or parts[0] != "ggsel"
                or parts[1] != "edit_option_hours"
        ):
            await callback.answer(
                "Некорректный callback.",
                show_alert=True,
            )
            return

        try:
            offer_id = self.parse_positive_int(
                parts[2],
                "GGsel ID",
            )

            option_id = self.parse_positive_int(
                parts[3],
                "Option ID",
            )

            variant_id = self.parse_positive_int(
                parts[4],
                "Variant ID",
            )
        except ValueError:
            await callback.answer(
                "Некорректный ID.",
                show_alert=True,
            )
            return

        data = await state.get_data()

        # Не теряем данные редактирования.
        await state.update_data(
            edit_option=True,
            offer_id=offer_id,
            option_id=option_id,
            variant_id=variant_id,
        )

        current_hours = data.get("option_hours")

        current_text = (
            str(current_hours)
            if current_hours is not None
            else "не указано"
        )

        if callback.message:
            await callback.message.answer(
                "Изменение времени option.\n\n"
                f"Текущее значение: "
                f"<b>{current_text} ч.</b>\n\n"
                f"Введите новое количество часов.\n"
                f"Максимум: <b>{MAX_HOURS}</b>.",
                reply_markup=self.cancel_keyboard(),
            )

        await state.set_state(
            OptionStates.editing_hours
        )

        await callback.answer()

    async def receive_edit_option_hours(
            self,
            message: Message,
            state: FSMContext,
    ) -> None:
        if not self.is_admin(
                message.from_user.id
                if message.from_user
                else None
        ):
            return

        try:
            hours = self.parse_positive_int(
                message.text or "",
                "Количество часов",
            )
        except ValueError as exc:
            await message.answer(str(exc))
            return

        if hours > MAX_HOURS:
            await message.answer(
                "Слишком большое количество часов."
            )
            return

        data = await state.get_data()

        try:
            offer_id = self.parse_positive_int(
                str(data["offer_id"]),
                "GGsel ID",
            )

            variant_id = self.parse_positive_int(
                str(data["variant_id"]),
                "Variant ID",
            )
        except (
                KeyError,
                ValueError,
        ):
            await state.clear()

            await message.answer(
                "Сессия редактирования потеряна."
            )
            return

        try:
            game = await self.db.get_game_by_ggsel_product(
                ggsel_product_id=offer_id,
            )

            if game is None:
                await message.answer(
                    "Для этого GGsel товара не найдена привязанная игра."
                )
                return

            game_id = int(game["id"])

            options = await self.ggsel.get_options(
                offer_id=offer_id,
            )
            option_id: int | None = None

            for option in options:
                variants = self.get_variants(option)

                for variant in variants:
                    if self.normalize_id(variant.get("id")) == variant_id:
                        option_id = self.normalize_id(option.get("id"))
                        break

                if option_id is not None:
                    break

            if option_id is None:
                await message.answer(
                    "Variant не найден среди options GGsel."
                )
                return
            # Получаем актуальный вариант непосредственно с GGsel.
            option = await self.ggsel.get_option(
                offer_id=offer_id,
                option_id=option_id,
            )

            target = next(
                (
                    item
                    for item in self.get_variants(option)
                    if self.normalize_id(item.get("id")) == variant_id
                ),
                None,
            )

            if target is None:
                await message.answer(
                    "Variant не найден на GGsel."
                )
                return

            variant_price = target.get("price")

            try:
                variant_price = float(variant_price)
            except (TypeError, ValueError):
                await message.answer(
                    "GGsel вернул некорректную цену variant."
                )
                return

            # Получаем базовую цену offer.
            offer = await self.ggsel.get_offer(
                offer_id=offer_id,
            )

            offer_data = offer.get("data")

            if not isinstance(offer_data, dict):
                raise ValueError(
                    "GGsel offer response не содержит data"
                )

            base_price = float(
                offer_data.get("price", 0)
            )

            # При impact_type="increase":
            # итоговая цена = базовая цена + modifier.
            final_price = base_price + variant_price

            await self.db.set_rental_variant_hours(
                game_id=game_id,
                ggsel_product_id=offer_id,
                ggsel_variant_id=variant_id,
                hours=hours,
                price_rub=final_price,
            )

        except ValueError as exc:
            logger.error(
                "Failed to save rental variant: "
                "offer_id=%s variant_id=%s error=%s",
                offer_id,
                variant_id,
                exc,
            )

            await message.answer(
                "Не удалось сохранить локальную настройку."
            )
            return

        except Exception:
            logger.exception(
                "Failed to update option hours: "
                "offer_id=%s variant_id=%s hours=%s",
                offer_id,
                variant_id,
                hours,
            )

            await message.answer(
                "Не удалось сохранить время."
            )
            return

        await state.update_data(
            option_hours=hours,
        )

        await message.answer(
            "Время option обновлено.\n\n"
            f"Новое значение: <b>{hours} ч.</b>"
        )


    @staticmethod
    def parse_price(
        value: str,
    ) -> Decimal:
        raw = (
            value
            .strip()
            .replace(",", ".")
            .replace("₽", "")
            .strip()
        )

        try:
            price = Decimal(raw)
        except InvalidOperation:
            raise ValueError(
                "Цена должна быть числом.\n\n"
                "Например: <code>299</code>"
            )

        if not price.is_finite():
            raise ValueError(
                "Некорректная цена."
            )

        if price < 0:
            raise ValueError(
                "Цена не может быть отрицательной."
            )

        if price > MAX_PRICE:
            raise ValueError(
                "Цена слишком большая."
            )

        return price

    # ========================================================
    # GGSEL HELPERS
    # ========================================================

    @staticmethod
    def normalize_id(
        value: Any,
    ) -> int | None:
        try:
            if value is None:
                return None

            result = int(value)

            if result <= 0:
                return None

            return result

        except (TypeError, ValueError):
            return None

    @staticmethod
    def calculate_price_modifier(
        *,
        base_price: Decimal,
        final_price: Decimal,
    ) -> tuple[Decimal, str]:
        """Return GGsel modifier value and its direction.

        The administrator always enters the final customer price.
        GGsel receives only the absolute difference from the offer base
        price plus the corresponding impact direction.
        """
        difference = final_price - base_price

        if difference == 0:
            return Decimal("0"), "increase"

        if difference > 0:
            return difference, "increase"

        return abs(difference), "decrease"

    @staticmethod
    def get_variant_final_price(
        *,
        base_price: Decimal,
        variant: dict[str, Any],
    ) -> Decimal:
        """Convert GGsel modifier data to the final customer price."""
        try:
            modifier = Decimal(str(variant.get("price", "0")))
        except (InvalidOperation, ValueError, TypeError):
            return Decimal("0")

        impact_type = str(
            variant.get("impact_type")
            or variant.get("modify_type")
            or "increase"
        ).lower()

        if impact_type in {"decrease", "subtract", "minus"}:
            return base_price - modifier

        return base_price + modifier

    @staticmethod
    def get_variants(
        option: dict[str, Any],
    ) -> list[dict[str, Any]]:
        variants = option.get("variants")

        if not isinstance(variants, list):
            return []

        return [
            item
            for item in variants
            if isinstance(item, dict)
        ]

    @staticmethod
    def option_title(
        option: dict[str, Any],
    ) -> str:
        return str(
            option.get("title")
            or option.get("name")
            or option.get("title_ru")
            or option.get("display_name")
            or f"Option {option.get('id', '?')}"
        )

    @staticmethod
    def variant_title(
        variant: dict[str, Any],
    ) -> str:
        return str(
            variant.get("title_ru")
            or variant.get("title_en")
            or f"Variant {variant.get('id', '?')}"
        )

    # ========================================================
    # COMMON KEYBOARDS
    # ========================================================

    @staticmethod
    def cancel_keyboard() -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="❌ Отмена",
                        callback_data="ggsel:cancel",
                    ),
                ],
            ],
        )

    # ========================================================
    # OFFER KEYBOARD
    # ========================================================

    @staticmethod
    def offer_keyboard(
        *,
        offer_id: int,
        variant: dict[str, Any] | None,
    ) -> InlineKeyboardMarkup:
        rows: list[list[InlineKeyboardButton]] = []

        if variant is None:
            rows.append(
                [
                    InlineKeyboardButton(
                        text="➕ Добавить Variant (0/1)",
                        callback_data=(
                            f"ggsel:add_variant:"
                            f"{offer_id}"
                        ),
                    ),
                ]
            )

        else:
            variant_id = GgselBot.normalize_id(
                variant.get("id")
            )

            if variant_id is not None:
                rows.append(
                    [
                        InlineKeyboardButton(
                            text=(
                                "🧩 "
                                f"{GgselBot.option_title(variant)}"
                            ),
                            callback_data=(
                                f"ggsel:variant:"
                                f"{offer_id}:"
                                f"{variant_id}"
                            ),
                        ),
                    ]
                )
        rows.append(
            [
                InlineKeyboardButton(
                    text="Снять с продажи",
                    callback_data=(
                        f"ggsel:disable:{offer_id}"
                    ),
                ),
            ]
        )
        rows.append(
            [
                InlineKeyboardButton(
                    text="Выставить на продажу",
                    callback_data=(
                        f"ggsel:activate:{offer_id}"
                    ),
                ),
            ]
        )


        return InlineKeyboardMarkup(
            inline_keyboard=rows,
        )

    # ========================================================
    # OPTION KEYBOARD
    # ========================================================

    @staticmethod
    def option_keyboard(
        *,
        offer_id: int,
        option_id: int,
        variants: list[dict[str, Any]],
    ) -> InlineKeyboardMarkup:
        rows: list[list[InlineKeyboardButton]] = []

        valid_variants = [
            variant
            for variant in variants
            if GgselBot.normalize_id(
                variant.get("id")
            ) is not None
        ]

        # ----------------------------------------------------
        # Каждый GGsel Variant =
        # пользовательский Option.
        #
        # Нажатие сразу открывает edit_option.
        # ----------------------------------------------------

        for variant in valid_variants:
            variant_id = GgselBot.normalize_id(
                variant.get("id")
            )

            if variant_id is None:
                continue

            title = GgselBot.variant_title(
                variant
            )

            rows.append(
                [
                    InlineKeyboardButton(
                        text=f"⚙️ {title}",
                        callback_data=(
                            f"ggsel:edit_option:"
                            f"{offer_id}:"
                            f"{option_id}:"
                            f"{variant_id}"
                        ),
                    ),
                ]
            )

        # ----------------------------------------------------
        # Add option
        # ----------------------------------------------------

        if len(valid_variants) < MAX_OPTIONS:
            rows.append(
                [
                    InlineKeyboardButton(
                        text=(
                            "➕ Добавить option "
                            f"({len(valid_variants)}/"
                            f"{MAX_OPTIONS})"
                        ),
                        callback_data=(
                            f"ggsel:add_option:"
                            f"{offer_id}:"
                            f"{option_id}"
                        ),
                    ),
                ]
            )

        else:
            rows.append(
                [
                    InlineKeyboardButton(
                        text=(
                            f"{MAX_OPTIONS}/{MAX_OPTIONS} "
                            "options создано"
                        ),
                        callback_data="ggsel:no_action",
                    ),
                ]
            )

        # ----------------------------------------------------
        # Back
        # ----------------------------------------------------

        rows.append(
            [
                InlineKeyboardButton(
                    text="⬅️ К карточке",
                    callback_data=(
                        f"ggsel:offer:"
                        f"{offer_id}"
                    ),
                ),
            ]
        )


        return InlineKeyboardMarkup(
            inline_keyboard=rows,
        )

    # ========================================================
    # EDIT OPTION KEYBOARD
    # ========================================================

    @staticmethod
    def edit_option_keyboard(
            *,
            offer_id: int,
            option_id: int,
            variant_id: int,
            is_default: bool = False,
            has_hours: bool = False,
    ) -> InlineKeyboardMarkup:
        buttons = [
            [
                InlineKeyboardButton(
                    text="🇷🇺 Название RU",
                    callback_data=(
                        f"ggsel:edit_option_title_ru:"
                        f"{offer_id}:"
                        f"{option_id}:"
                        f"{variant_id}"
                    ),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="🇺🇸 Название EN",
                    callback_data=(
                        f"ggsel:edit_option_title_en:"
                        f"{offer_id}:"
                        f"{option_id}:"
                        f"{variant_id}"
                    ),
                ),
            ],
        ]

        if not is_default:
            buttons.append(
                [
                    InlineKeyboardButton(
                        text="Цена",
                        callback_data=(
                            f"ggsel:edit_option_price:"
                            f"{offer_id}:"
                            f"{option_id}:"
                            f"{variant_id}"
                        ),
                    ),
                ],
            )

            if has_hours:
                buttons.append(
                    [
                        InlineKeyboardButton(
                            text="Изменить статус",
                            callback_data=(
                                f"ggsel:edit_option_status:"
                                f"{offer_id}:"
                                f"{option_id}:"
                                f"{variant_id}"
                            ),
                        ),
                    ]
                )

        buttons.extend(
            [
                [
                    InlineKeyboardButton(
                        text=("⚠️ " if not has_hours else "") + "Изменить часы",
                        callback_data=(
                            f"ggsel:edit_option_hours:"
                            f"{offer_id}:"
                            f"{option_id}:"
                            f"{variant_id}"
                        ),
                    ),
                ],
                [
                    InlineKeyboardButton(
                        text="⬅️ Назад",
                        callback_data=(
                            f"ggsel:variant:"
                            f"{offer_id}:"
                            f"{option_id}"
                        ),
                    ),
                ],
            ]
        )

        return InlineKeyboardMarkup(
            inline_keyboard=buttons,
        )

    # ========================================================
    # /start
    # ========================================================

    async def handler_start(
        self,
        message: Message,
    ) -> None:
        await message.answer(
            "Первоначально нужно использовать /mapping для связки игр kosell -> ggsel, иначе система не поймет, к чему относится ваша карточка на ggsel.\n\n"
            "<blockquote>Если вы присоединяете карточку уже с готовыми радио-кнопками по типу \"Аренда на день\", следует оповестить систему о том, на сколько часов нужно брать аккаунт в аренду.</blockquote>"
        )

    # ========================================================
    # /mapping
    # ========================================================

    async def start_mapping(
        self,
        message: Message,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            message.from_user.id
            if message.from_user
            else None
        ):
            return

        await state.clear()

        await message.answer(
            "Создание mapping GGsel → Kosell.\n\n"
            "Отправь ID карточки GGsel.\n\n"
            "Например:\n"
            "<code>102750993</code>"
        )

        await state.set_state(
            MappingStates.waiting_ggsel_id
        )

    # ========================================================
    # RECEIVE GGSEL ID
    # ========================================================

    async def receive_ggsel_id(
        self,
        message: Message,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            message.from_user.id
            if message.from_user
            else None
        ):
            return

        try:
            ggsel_product_id = self.parse_positive_int(
                message.text or "",
                "GGsel ID",
            )
        except ValueError as exc:
            await message.answer(str(exc))
            return

        try:
            existing_game = (
                await self.db.get_game_by_ggsel_product(
                    ggsel_product_id=ggsel_product_id,
                )
            )
        except Exception:
            logger.exception(
                "Failed to check mapping %s",
                ggsel_product_id,
            )

            await message.answer(
                "Не удалось проверить mapping."
            )
            return

        if existing_game is not None:
            await state.clear()

            await message.answer(
                "Эта карточка уже связана.\n\n"
                f"Игра: <b>{existing_game['name']}</b>\n"
                f"GGsel: "
                f"<code>{ggsel_product_id}</code>\n"
                f"Kosell: "
                f"<code>{existing_game['kosell_product_id']}</code>"
            )

            await self.send_offer_message(
                message=message,
                offer_id=ggsel_product_id,
                game=existing_game,
            )
            return

        try:
            offer = await self.ggsel.get_offer(
                offer_id=ggsel_product_id,
            )
        except Exception:
            logger.exception(
                "Failed to get GGsel offer %s",
                ggsel_product_id,
            )

            await message.answer(
                "Не удалось получить карточку GGsel.\n\n"
                "Проверь ID."
            )
            return

        offer_name = ""

        if isinstance(offer, dict):
            offer_name = str(
                offer.get("title")
                or offer.get("name")
                or offer.get("title_ru")
                or ""
            ).strip()

        await state.update_data(
            ggsel_product_id=ggsel_product_id,
        )

        text = (
            "Карточка GGsel найдена.\n\n"
            f"GGsel ID: "
            f"<code>{ggsel_product_id}</code>"
        )

        if offer_name:
            text += (
                f"\nНазвание: <b>{offer_name}</b>"
            )

        text += (
            "\n\nТеперь отправь "
            "<b>Kosell Product ID</b>."
        )

        await message.answer(
            text,
            reply_markup=self.cancel_keyboard(),
        )

        await state.set_state(
            MappingStates.waiting_kosell_product_id
        )

    # ========================================================
    # RECEIVE KOSELL ID
    # ========================================================

    async def receive_kosell_product_id(
        self,
        message: Message,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            message.from_user.id
            if message.from_user
            else None
        ):
            return

        try:
            kosell_product_id = self.parse_positive_int(
                message.text or "",
                "Kosell Product ID",
            )
        except ValueError as exc:
            await message.answer(str(exc))
            return

        data = await state.get_data()

        ggsel_product_id = data.get(
            "ggsel_product_id"
        )

        if ggsel_product_id is None:
            await state.clear()

            await message.answer(
                "Сессия потеряна.\n\n"
                "Начни заново через /mapping."
            )
            return

        try:
            products = await self.kosell.get_rental_products()
        except Exception:
            logger.exception(
                "Failed to get Kosell products"
            )

            await message.answer(
                "Не удалось получить товары Kosell."
            )
            return

        product = next(
            (
                item
                for item in products
                if (
                    isinstance(item, dict)
                    and self.normalize_id(item.get("id"))
                    == kosell_product_id
                )
            ),
            None,
        )

        if product is None:
            await message.answer(
                "Kosell Product не найден.\n\n"
                f"ID: <code>{kosell_product_id}</code>"
            )
            return

        game_name = str(
            product.get("name") or ""
        ).strip()

        if not game_name:
            await message.answer(
                "Kosell Product не имеет названия."
            )
            return

        try:
            game_id = await self.db.create_game_with_offer(
                name=game_name,
                kosell_product_id=kosell_product_id,
                ggsel_product_id=int(
                    ggsel_product_id
                ),
            )
        except ValueError as exc:
            await message.answer(
                f"Не удалось создать mapping.\n\n{exc}"
            )
            return
        except Exception:
            logger.exception(
                "Failed to create mapping"
            )

            await message.answer(
                "Не удалось создать mapping."
            )
            return

        await state.clear()

        await message.answer(
            "Mapping создан.\n\n"
            f"Game ID: <code>{game_id}</code>\n"
            f"GGsel: <code>{ggsel_product_id}</code>\n"
            f"Kosell: <code>{kosell_product_id}</code>\n"
            f"Игра: <b>{game_name}</b>"
        )

        game = await self.db.get_game_by_ggsel_product(
            ggsel_product_id=int(
                ggsel_product_id
            )
        )

        if game is None:
            await message.answer(
                "Mapping создан, но игра не найдена."
            )
            return

        await self.send_offer_message(
            message=message,
            offer_id=int(ggsel_product_id),
            game=game,
        )

    # ========================================================
    # SHOW OFFER
    # ========================================================

    async def send_offer_message(
        self,
        *,
        message: Message,
        offer_id: int,
        game: Any,
    ) -> None:
        try:
            options = await self.ggsel.get_options(
                offer_id=offer_id,
            )
        except Exception:
            logger.exception(
                "Failed to get GGsel options for offer %s",
                offer_id,
            )

            await message.answer(
                "Не удалось получить данные карточки GGsel."
            )
            return

        variant: dict[str, Any] | None = None

        for item in options:
            if not isinstance(item, dict):
                continue

            if self.normalize_id(
                item.get("id")
            ) is None:
                continue

            variant = item
            break

        text = (
            f"Карточка GGsel "
            f"<code>{offer_id}</code>\n\n"
            f"Игра: <b>{game['name']}</b>\n"
            f"Kosell Product ID: "
            f"<code>{game['kosell_product_id']}</code>\n\n"
        )

        if variant is None:
            text += (
                "Variant: <b>нет</b>\n\n"
                "Создай первый Variant."
            )
        else:
            variant_id = self.normalize_id(
                variant.get("id")
            )

            text += (
                "Variant: "
                f"<b>{self.option_title(variant)}</b>\n"
            )

            if variant_id is not None:
                text += (
                    "Variant ID: "
                    f"<code>{variant_id}</code>\n\n"
                )

            text += (
                "Нажми на Variant, чтобы управлять "
                "его Options."
            )

        await message.answer(
            text,
            reply_markup=self.offer_keyboard(
                offer_id=offer_id,
                variant=variant,
            ),
        )

    async def show_offer(
        self,
        callback: CallbackQuery,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        parts = (callback.data or "").split(":")

        if len(parts) != 3:
            await callback.answer(
                "Некорректный callback.",
                show_alert=True,
            )
            return

        try:
            offer_id = self.parse_positive_int(
                parts[2],
                "GGsel ID",
            )
        except ValueError:
            await callback.answer(
                "Некорректный GGsel ID.",
                show_alert=True,
            )
            return

        try:
            game = (
                await self.db.get_game_by_ggsel_product(
                    ggsel_product_id=offer_id,
                )
            )
        except Exception:
            logger.exception(
                "Failed to get mapping %s",
                offer_id,
            )

            await callback.answer(
                "Ошибка получения mapping.",
                show_alert=True,
            )
            return

        if game is None:
            await callback.answer(
                "Mapping не найден.",
                show_alert=True,
            )
            return

        try:
            options = await self.ggsel.get_options(
                offer_id=offer_id,
            )
        except Exception:
            logger.exception(
                "Failed to get options %s",
                offer_id,
            )

            await callback.answer(
                "Ошибка получения options.",
                show_alert=True,
            )
            return

        options = [
            item
            for item in options
            if isinstance(item, dict)
        ]

        variant = options[0] if options else None

        text = (
            f"Карточка GGsel "
            f"<code>{offer_id}</code>\n\n"
            f"Игра: <b>{game['name']}</b>\n"
            f"Kosell Product ID: "
            f"<code>{game['kosell_product_id']}</code>\n\n"
        )

        if variant is None:
            text += (
                "Variant: <b>нет</b>\n\n"
                "Создай первый Variant."
            )
        else:
            variant_id = self.normalize_id(
                variant.get("id")
            )

            text += (
                "Variant: "
                f"<b>{self.option_title(variant)}</b>\n"
            )

            if variant_id is not None:
                text += (
                    "Variant ID: "
                    f"<code>{variant_id}</code>\n\n"
                )

            text += (
                "Нажми на Variant, чтобы управлять "
                "его Options."
            )

        if callback.message:
            await callback.message.edit_text(
                text,
                reply_markup=self.offer_keyboard(
                    offer_id=offer_id,
                    variant=variant,
                ),
            )

        await callback.answer()

    # ========================================================
    # SHOW VARIANT
    # ========================================================

    async def render_variant(
            self,
            *,
            message: Message,
            offer_id: int,
            option_id: int,
    ) -> None:
        try:
            option = await self.ggsel.get_option(
                offer_id=offer_id,
                option_id=option_id,
            )
        except Exception:
            logger.exception(
                "Failed to get GGsel option: "
                "offer_id=%s option_id=%s",
                offer_id,
                option_id,
            )

            await message.edit_text(
                "Не удалось получить Variant."
            )
            return

        variants = self.get_variants(option)

        variants = [
            item
            for item in variants
            if self.normalize_id(
                item.get("id")
            ) is not None
        ]

        # --------------------------------------------------------
        # Синхронизируем видимость вариантов GGsel.
        #
        # Если variant активен на GGsel, но у нас не настроены
        # часы — скрываем его на GGsel.
        # --------------------------------------------------------
        warnings: list[str] = []
        for item in variants:
            variant_id = self.normalize_id(
                item.get("id")
            )

            if variant_id is None:
                continue

            ggsel_status = str(
                item.get("status") or "active"
            )

            try:
                rental_variant = (
                    await self.db.get_rental_variant_by_ggsel_variant(
                        ggsel_product_id=offer_id,
                        ggsel_variant_id=variant_id,
                    )
                )

                hours = None

                if rental_variant is not None:
                    try:
                        hours = int(
                            rental_variant["hours"]
                        )
                    except (
                            TypeError,
                            ValueError,
                            KeyError,
                    ):
                        hours = None

                # Нет локальной настройки часов.
                is_default = bool(item.get("is_default"))

                if hours is None:
                    if is_default:
                        logger.warning(
                            "Cannot hide default GGsel variant: "
                            "offer_id=%s option_id=%s variant_id=%s",
                            offer_id,
                            option_id,
                            variant_id,
                        )

                        if hours is None and is_default:
                            warnings.append(
                                f"• <b>{self.variant_title(item)}</b> "
                                f"(ID <code>{variant_id}</code>) — "
                                "не указано количество часов. "
                                "Укажите часы, чтобы вариант был доступен."
                            )

                            continue

                    if ggsel_status == "active":
                        await self.ggsel.update_variant_visibility(
                            offer_id=offer_id,
                            option_id=option_id,
                            variant_id=variant_id,
                            status="hidden",
                        )

                        logger.info(
                            "GGsel variant hidden: "
                            "offer_id=%s option_id=%s variant_id=%s "
                            "reason=no_hours",
                            offer_id,
                            option_id,
                            variant_id,
                        )

                        # Обновляем локальное представление,
                        # чтобы дальше UI не считал его активным.
                        item["status"] = "hidden"

                # Часы настроены — вариант должен быть активным.
                else:
                    if ggsel_status == "hidden":
                        await self.ggsel.update_variant_visibility(
                            offer_id=offer_id,
                            option_id=option_id,
                            variant_id=variant_id,
                            status="active",
                        )

                        logger.info(
                            "GGsel variant activated: "
                            "offer_id=%s option_id=%s variant_id=%s "
                            "hours=%s",
                            offer_id,
                            option_id,
                            variant_id,
                            hours,
                        )

                        item["status"] = "active"

            except Exception:
                logger.exception(
                    "Failed to synchronize variant visibility: "
                    "offer_id=%s option_id=%s variant_id=%s",
                    offer_id,
                    option_id,
                    variant_id,
                )

        text = (
            f"Variant: "
            f"<b>{self.option_title(option)}</b>\n\n"
            f"Variant ID: "
            f"<code>{option_id}</code>\n"
            f"Options: "
            f"<b>{len(variants)}/{MAX_OPTIONS}</b>\n\n"
        )

        if variants:
            text += "Выбери option."
        else:
            text += (
                "Options пока нет.\n\n"
                "Создай первый option."
            )

        if warnings:
            text += (
                    "\n\n"
                    "⚠️ <b>Требуется настройка</b>\n\n"
                    + "\n".join(warnings)
            )
        await message.edit_text(
            text,
            reply_markup=self.option_keyboard(
                offer_id=offer_id,
                option_id=option_id,
                variants=variants,
            ),
        )

    async def show_variant(
            self,
            callback: CallbackQuery,
    ) -> None:
        if not self.is_admin(
                callback.from_user.id
                if callback.from_user
                else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        parts = (callback.data or "").split(":")

        if len(parts) != 4:
            await callback.answer(
                "Некорректный callback.",
                show_alert=True,
            )
            return

        try:
            offer_id = self.parse_positive_int(
                parts[2],
                "GGsel ID",
            )

            option_id = self.parse_positive_int(
                parts[3],
                "Option ID",
            )
        except ValueError:
            await callback.answer(
                "Некорректный ID.",
                show_alert=True,
            )
            return

        if callback.message:
            await self.render_variant(
                message=callback.message,
                offer_id=offer_id,
                option_id=option_id,
            )

        await callback.answer()
    # ========================================================
    # EDIT OPTION
    # ========================================================

    async def edit_option(
            self,
            callback: CallbackQuery,
            state: FSMContext,
    ) -> None:
        if not self.is_admin(
                callback.from_user.id
                if callback.from_user
                else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        parts = (callback.data or "").split(":")

        if (
                len(parts) != 5
                or parts[0] != "ggsel"
                or parts[1] != "edit_option"
        ):
            await callback.answer(
                "Некорректный callback.",
                show_alert=True,
            )
            return

        try:
            offer_id = self.parse_positive_int(
                parts[2],
                "GGsel ID",
            )

            option_id = self.parse_positive_int(
                parts[3],
                "Option ID",
            )

            variant_id = self.parse_positive_int(
                parts[4],
                "Variant ID",
            )
        except ValueError:
            await callback.answer(
                "Некорректный ID.",
                show_alert=True,
            )
            return

        # --------------------------------------------------------
        # Получаем Option-контейнер GGsel.
        # --------------------------------------------------------

        try:
            option = await self.ggsel.get_option(
                offer_id=offer_id,
                option_id=option_id,
            )
        except Exception:
            logger.exception(
                "Failed to get option: "
                "offer_id=%s option_id=%s variant_id=%s",
                offer_id,
                option_id,
                variant_id,
            )

            await callback.answer(
                "Не удалось получить option.",
                show_alert=True,
            )
            return
        logger.info("OPTION %s", option)
        # --------------------------------------------------------
        # Ищем конкретный Variant внутри Option.
        # --------------------------------------------------------

        target = next(
            (
                item
                for item in self.get_variants(option)
                if self.normalize_id(
                item.get("id")
            ) == variant_id
            ),
            None,
        )

        if target is None:
            await callback.answer(
                "Option не найден.",
                show_alert=True,
            )
            return

        # --------------------------------------------------------
        # Данные из GGsel.
        # --------------------------------------------------------

        title_ru = str(
            target.get("title_ru") or ""
        )

        title_en = str(
            target.get("title_en") or ""
        )

        price = target.get("price")
        logger.info("PRICE %s", price)
        logger.info("TARGET %s", target)

        offer = await self.ggsel.get_offer(
            offer_id=offer_id,
        )
        offer_data = offer.get("data")

        if not isinstance(offer_data, dict):
            raise ValueError(
                "GGsel offer response не содержит data"
            )

        base_price = Decimal(
            str(offer_data["price"])
        )

        normalized_price = self.get_variant_final_price(
            base_price=base_price,
            variant=target,
        )
        logger.info("NORM_PRICE %s", normalized_price)

        status = str(
            target.get("status")
            or "active"
        )

        is_default = bool(
            target.get("is_default")
        )

        position = target.get(
            "position",
            0,
        )

        try:
            position = int(position)
        except (
                TypeError,
                ValueError,
        ):
            position = 0

        # --------------------------------------------------------
        # Получаем часы из нашей БД.
        #
        # GGsel их не хранит.
        # --------------------------------------------------------
        try:
            rental_variant = await self.db.get_rental_variant_by_ggsel_variant(
                ggsel_product_id=offer_id,
                ggsel_variant_id=variant_id,
            )

            if rental_variant is None:
                hours = None
            else:
                try:
                    logger.info("RENTAL_VARIANT %s", rental_variant)
                    hours = int(rental_variant["hours"])
                except (TypeError, ValueError, KeyError):
                    logger.warning(
                        "Invalid rental variant hours: "
                        "offer_id=%s variant_id=%s hours=%r",
                        offer_id,
                        variant_id,
                        rental_variant.get("hours"),
                    )
                    hours = None

        except Exception:
            logger.exception(
                "Failed to get rental variant from DB: "
                "offer_id=%s variant_id=%s",
                offer_id,
                variant_id,
            )

            await callback.answer(
                "Не удалось получить данные о часах.",
                show_alert=True,
            )
            return

        # --------------------------------------------------------
        # Сохраняем всё в FSM.
        # --------------------------------------------------------

        await state.clear()

        await state.update_data(
            edit_option=True,
            offer_id=offer_id,
            option_id=option_id,
            variant_id=variant_id,
            option_title_ru=title_ru,
            option_title_en=title_en,
            option_price=str(
                normalized_price
            ),
            option_status=status,
            option_is_default=is_default,
            option_position=position,
            option_hours=hours,
        )

        # --------------------------------------------------------
        # Формируем экран.
        # --------------------------------------------------------

        hours_text = (
            f"{hours} ч."
            if hours is not None
            else "не указано"
        )

        text = (
            "<b>Редактирование option</b>\n\n"
            f"RU: <b>{title_ru or '—'}</b>\n"
            f"EN: <b>{title_en or '—'}</b>\n"
            f"Цена: <b>{normalized_price:g} ₽</b>\n"
            f"Время: <b>{hours_text}</b>\n"
            f"Статус: <b>{status}</b>\n"
            f"По умолчанию: "
            f"<b>{'Да' if is_default else 'Нет'}</b>\n\n"
            f"Option ID: "
            f"<code>{variant_id}</code>\n\n"
            "Что изменить?"
            f"{"\n\n<blockquote>Цена для товара по умолчанию меняется в личном кабинете.</blockquote>" if is_default else ""}"
        )

        if callback.message:
            await callback.message.edit_text(
                text,
                reply_markup=self.edit_option_keyboard(
                    offer_id=offer_id,
                    option_id=option_id,
                    variant_id=variant_id,
                    has_hours=not not hours,
                    is_default=is_default
                ),
            )

        await callback.answer()

    # ========================================================
    # EDIT OPTION TITLE RU
    # ========================================================

    async def edit_option_title_ru(
        self,
        callback: CallbackQuery,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        data = await state.get_data()

        if data.get("variant_id") is None:
            await callback.answer(
                "Сессия редактирования потеряна.",
                show_alert=True,
            )
            return

        await callback.answer()

        if callback.message:
            await callback.message.answer(
                "Введите новое название option RU:",
                reply_markup=self.cancel_keyboard(),
            )

        await state.set_state(
            OptionStates.waiting_title_ru
        )

        await state.update_data(
            edit_option=True,
        )

    # ========================================================
    # EDIT OPTION TITLE EN
    # ========================================================

    async def edit_option_title_en(
        self,
        callback: CallbackQuery,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        data = await state.get_data()

        if data.get("variant_id") is None:
            await callback.answer(
                "Сессия редактирования потеряна.",
                show_alert=True,
            )
            return

        await callback.answer()

        if callback.message:
            await callback.message.answer(
                "Введите новое название option EN:",
                reply_markup=self.cancel_keyboard(),
            )

        await state.set_state(
            OptionStates.waiting_title_en
        )

        await state.update_data(
            edit_option=True,
        )

    # ========================================================
    # EDIT OPTION PRICE
    # ========================================================

    async def edit_option_price(
        self,
        callback: CallbackQuery,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        data = await state.get_data()

        if data.get("variant_id") is None:
            await callback.answer(
                "Сессия редактирования потеряна.",
                show_alert=True,
            )
            return

        await callback.answer()

        if callback.message:
            await callback.message.answer(
                "Введите новую цену:",
                reply_markup=self.cancel_keyboard(),
            )

        await state.set_state(
            OptionStates.waiting_price
        )

        await state.update_data(
            edit_option=True,
        )

    # ========================================================
    # EDIT OPTION STATUS
    # ========================================================

    async def edit_option_status(
        self,
        callback: CallbackQuery,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        data = await state.get_data()

        if data.get("variant_id") is None:
            await callback.answer(
                "Сессия редактирования потеряна.",
                show_alert=True,
            )
            return

        await callback.answer()

        if callback.message:
            await callback.message.answer(
                "Выбери статус:",
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="🟢 Active",
                                callback_data=(
                                    "ggsel:set_option_status:"
                                    "active"
                                ),
                            ),
                        ],
                        [
                            InlineKeyboardButton(
                                text="🔴 Inactive",
                                callback_data=(
                                    "ggsel:set_option_status:"
                                    "inactive"
                                ),
                            ),
                        ],
                        [
                            InlineKeyboardButton(
                                text="❌ Отмена",
                                callback_data=(
                                    "ggsel:cancel"
                                ),
                            ),
                        ],
                    ],
                ),
            )

    # ========================================================
    # RECEIVE OPTION TITLE RU
    # ========================================================

    async def receive_option_title_ru(
        self,
        message: Message,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            message.from_user.id
            if message.from_user
            else None
        ):
            return

        value = (message.text or "").strip()

        if not value:
            await message.answer(
                "Название option RU не может быть пустым."
            )
            return

        if len(value) > MAX_TITLE_LENGTH:
            await message.answer(
                "Название слишком длинное."
            )
            return

        data = await state.get_data()

        if data.get("edit_option"):
            await state.update_data(
                option_title_ru=value,
            )

            await self._save_edited_option(
                message=message,
                state=state,
            )
            return

        if data.get("offer_id") is None:
            await state.clear()

            await message.answer(
                "Сессия потеряна."
            )
            return

        if data.get("option_id") is None:
            await state.clear()

            await message.answer(
                "Variant не найден."
            )
            return

        await state.update_data(
            option_title_ru=value,
        )

        await message.answer(
            "Введите название option на английском:",
            reply_markup=self.cancel_keyboard(),
        )

        await state.set_state(
            OptionStates.waiting_title_en
        )

    # ========================================================
    # RECEIVE OPTION TITLE EN
    # ========================================================

    async def receive_option_title_en(
        self,
        message: Message,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            message.from_user.id
            if message.from_user
            else None
        ):
            return

        value = (message.text or "").strip()

        if not value:
            await message.answer(
                "Название option EN не может быть пустым."
            )
            return

        if len(value) > MAX_TITLE_LENGTH:
            await message.answer(
                "Название слишком длинное."
            )
            return

        data = await state.get_data()

        if data.get("edit_option"):
            await state.update_data(
                option_title_en=value,
            )

            await self._save_edited_option(
                message=message,
                state=state,
            )
            return

        if data.get("offer_id") is None:
            await state.clear()

            await message.answer(
                "Сессия потеряна."
            )
            return

        await state.update_data(
            option_title_en=value,
        )

        await message.answer(
            "Введите цену в рублях:",
            reply_markup=self.cancel_keyboard(),
        )

        await state.set_state(
            OptionStates.waiting_price
        )

    # ========================================================
    # RECEIVE OPTION PRICE
    # ========================================================

    async def receive_price(
            self,
            message: Message,
            state: FSMContext,
    ) -> None:
        if not self.is_admin(
                message.from_user.id
                if message.from_user
                else None
        ):
            return

        try:
            price = self.parse_price(
                message.text or ""
            )
        except ValueError as exc:
            await message.answer(str(exc))
            return

        data = await state.get_data()
        logger.warning(f"ЧЕ ЗА ХУЙНЯ: {data=}")
        if data.get("option_is_default"):
            await message.edit_text(
                "⚠️ Вы не можете менять цену у варианта по умолчанию."
            )
            return
        # --------------------------------------------------------
        # Редактирование существующего variant
        # --------------------------------------------------------

        if data.get("edit_option"):
            await state.update_data(
                option_price=str(price),
            )

            await self._save_edited_option(
                message=message,
                state=state,
            )
            return

        # --------------------------------------------------------
        # Создание нового variant.
        #
        # Пользователь вводит ИТОГОВУЮ цену.
        # GGsel при impact_type="increase"
        # получает только разницу относительно
        # базовой цены offer.
        # --------------------------------------------------------

        try:
            offer_id = int(
                data["offer_id"]
            )
        except (
                KeyError,
                TypeError,
                ValueError,
        ):
            await state.clear()

            await message.answer(
                "Не удалось определить GGsel offer."
            )
            return

        try:
            offer = await self.ggsel.get_offer(
                offer_id=offer_id,
            )

            offer_data = offer.get("data")
            logger.warning(f"OFFER_DATA= {offer_data=}")

            if not isinstance(
                    offer_data,
                    dict,
            ):
                raise ValueError(
                    "GGsel offer response не содержит data"
                )

            base_price = Decimal(
                str(
                    offer_data.get(
                        "price",
                        "0",
                    )
                )
            )

        except Exception:
            logger.exception(
                "Failed to get GGsel base price: "
                "offer_id=%s",
                offer_id,
            )

            await message.answer(
                "Не удалось получить базовую цену GGsel."
            )
            return

        modifier_price, impact_type = (
            self.calculate_price_modifier(
                base_price=base_price,
                final_price=price,
            )
        )

        logger.info(
            "GGsel price calculation: "
            "offer_id=%s base_price=%s "
            "final_price=%s modifier=%s impact_type=%s",
            offer_id,
            base_price,
            price,
            modifier_price,
            impact_type,
        )

        await state.update_data(
            option_price=str(price),
            option_price_modifier=str(modifier_price),
            option_impact_type=impact_type,
            option_base_price=str(base_price),
        )

        await message.answer(
            "Введите количество часов:\n\n"
            "Например:\n"
            "<code>72</code>",
            reply_markup=self.cancel_keyboard(),
        )

        await state.set_state(
            OptionStates.waiting_hours
        )

    # ========================================================
    # SAVE EDITED OPTION
    # ========================================================

    async def _save_edited_option(
            self,
            *,
            message: Message,
            state: FSMContext,
    ) -> None:
        data = await state.get_data()

        try:
            offer_id = int(data["offer_id"])
            option_id = int(data["option_id"])
            variant_id = int(data["variant_id"])

            title_ru = str(
                data.get("option_title_ru")
                or ""
            )

            title_en = str(
                data.get("option_title_en")
                or ""
            )

            price = Decimal(
                str(
                    data.get(
                        "option_price",
                        "0",
                    )
                )
            )

            status = str(
                data.get(
                    "option_status",
                    "active",
                )
            )

            is_default = bool(
                data.get(
                    "option_is_default",
                    False,
                )
            )

            position = int(
                data.get(
                    "option_position",
                    0,
                )
            )

        except (
                KeyError,
                TypeError,
                ValueError,
                InvalidOperation,
        ):
            await state.clear()

            await message.answer(
                "Сессия редактирования потеряна."
            )
            return

        if price < 0:
            await message.answer(
                "Цена не может быть отрицательной."
            )
            return

        # =========================================================
        # Получаем базовую цену GGsel
        # =========================================================

        try:
            offer = await self.ggsel.get_offer(
                offer_id=offer_id,
            )

            offer_data = offer.get("data")

            if not isinstance(offer_data, dict):
                raise ValueError(
                    "GGsel offer response не содержит data"
                )

            base_price = Decimal(
                str(offer_data["price"])
            )

        except Exception:
            logger.exception(
                "Failed to get GGsel base price: "
                "offer_id=%s",
                offer_id,
            )

            await message.answer(
                "Не удалось получить базовую цену товара GGsel."
            )
            return

        # =========================================================
        # Рассчитываем надбавку для rental_variants
        #
        # Например:
        # base_price = 3
        # price      = 20
        # rental_price = 17
        # =========================================================

        rental_price, impact_type = self.calculate_price_modifier(
            base_price=base_price,
            final_price=price,
        )

        logger.info(
            "Option price calculation: "
            "offer_id=%s variant_id=%s "
            "base_price=%s final_price=%s modifier=%s impact_type=%s",
            offer_id,
            variant_id,
            base_price,
            price,
            rental_price,
            impact_type,
        )

        # =========================================================
        # Обновляем цену варианта в GGsel
        # =========================================================

        try:
            result = (
                await self.ggsel.create_or_update_variant(
                    offer_id=offer_id,
                    option_id=option_id,
                    variant_id=variant_id,
                    title_ru=title_ru,
                    title_en=title_en,
                    price=rental_price,
                    discount_type="fixed",
                    impact_type=impact_type,
                    is_default=is_default,
                    status=status,
                    position=position,
                )
            )

        except Exception:
            logger.exception(
                "Failed to update GGsel option: "
                "offer_id=%s option_id=%s variant_id=%s",
                offer_id,
                option_id,
                variant_id,
            )

            await message.answer(
                "GGsel не принял изменение option."
            )
            return

        logger.info(
            "GGsel option updated: "
            "offer_id=%s option_id=%s variant_id=%s result=%r",
            offer_id,
            option_id,
            variant_id,
            result,
        )

        # =========================================================
        # Обновляем rental_variants
        # =========================================================

        try:
            game = await self.db.get_game_by_ggsel_product(
                ggsel_product_id=offer_id,
            )

            if game is None:
                logger.error(
                    "Game mapping not found: offer_id=%s",
                    offer_id,
                )

                await message.answer(
                    "GGsel обновлён, но для offer не найдена игра."
                )
                return

            game_id = int(game["id"])
            existing_variant = await self.db.get_rental_variant_by_ggsel_variant(
                ggsel_product_id=offer_id,
                ggsel_variant_id=variant_id,
            )
            hours = int(existing_variant["hours"])
            await self.db.upsert_rental_variant(
                game_id=game_id,
                ggsel_product_id=offer_id,
                ggsel_variant_id=variant_id,
                price_rub=float(price),
                hours=hours
            )

        except Exception:
            logger.exception(
                "GGsel variant updated but local DB update failed: "
                "offer_id=%s variant_id=%s rental_price=%s",
                offer_id,
                variant_id,
                rental_price,
            )

            await message.answer(
                "GGsel обновлён, но не удалось обновить "
                "цену варианта в локальной БД."
            )
            return

        await state.clear()

        await message.answer(
            "Option обновлён.\n\n"
            f"RU: <b>{title_ru}</b>\n"
            f"EN: <b>{title_en}</b>\n"
            f"Цена GGsel: <b>{price:g} ₽</b>\n"
            f"Базовая цена: <b>{base_price:g} ₽</b>\n"
            f"Модификатор GGsel: <b>{rental_price:g} ₽</b> ({impact_type})\n"
            f"Статус: <b>{status}</b>\n"
            f"ID: <code>{variant_id}</code>"
        )

        await self.send_option_message(
            message=message,
            offer_id=offer_id,
            option_id=option_id,
        )
    # ========================================================
    # SET STATUS
    # ========================================================

    async def set_option_status(
        self,
        callback: CallbackQuery,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        parts = (callback.data or "").split(":")

        if len(parts) != 3:
            await callback.answer(
                "Некорректный callback.",
                show_alert=True,
            )
            return

        status = parts[2]

        if status not in {
            "active",
            "inactive",
        }:
            await callback.answer(
                "Некорректный статус.",
                show_alert=True,
            )
            return

        data = await state.get_data()

        if data.get("variant_id") is None:
            await callback.answer(
                "Сессия редактирования потеряна.",
                show_alert=True,
            )
            return

        await state.update_data(
            option_status=status,
        )

        await self._save_edited_option(
            message=callback.message,
            state=state,
        )

        await callback.answer()

    # ========================================================
    # ADD OPTION
    # ========================================================

    async def start_add_option(
        self,
        callback: CallbackQuery,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        parts = (callback.data or "").split(":")

        if len(parts) != 4:
            await callback.answer(
                "Некорректный callback.",
                show_alert=True,
            )
            return

        try:
            offer_id = self.parse_positive_int(
                parts[2],
                "GGsel ID",
            )

            option_id = self.parse_positive_int(
                parts[3],
                "Variant ID",
            )
        except ValueError:
            await callback.answer(
                "Некорректный ID.",
                show_alert=True,
            )
            return

        try:
            container = await self.ggsel.get_option(
                offer_id=offer_id,
                option_id=option_id,
            )
        except Exception:
            logger.exception(
                "Failed to get Variant before "
                "creating option"
            )

            await callback.answer(
                "Не удалось получить Variant.",
                show_alert=True,
            )
            return

        variants = self.get_variants(
            container
        )

        if len(variants) >= MAX_OPTIONS:
            await callback.answer(
                "Можно создать максимум 5 options.",
                show_alert=True,
            )
            return

        await state.clear()

        await state.update_data(
            offer_id=offer_id,
            option_id=option_id,
            edit_option=False,
        )

        if callback.message:
            await callback.message.answer(
                "Создание option.\n\n"
                "Введите название option на русском:",
                reply_markup=self.cancel_keyboard(),
            )

        await state.set_state(
            OptionStates.waiting_title_ru
        )

        await callback.answer()

    # ========================================================
    # ADD VARIANT
    # ========================================================

    async def start_add_variant(
        self,
        callback: CallbackQuery,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            await callback.answer(
                "Нет доступа.",
                show_alert=True,
            )
            return

        parts = (callback.data or "").split(":")

        if len(parts) != 3:
            await callback.answer(
                "Некорректный callback.",
                show_alert=True,
            )
            return

        try:
            offer_id = self.parse_positive_int(
                parts[2],
                "GGsel ID",
            )
        except ValueError:
            await callback.answer(
                "Некорректный GGsel ID.",
                show_alert=True,
            )
            return

        try:
            options = await self.ggsel.get_options(
                offer_id=offer_id,
            )
        except Exception:
            logger.exception(
                "Failed to get options before "
                "creating variant"
            )

            await callback.answer(
                "Не удалось получить структуру карточки.",
                show_alert=True,
            )
            return

        if len(options) >= MAX_VARIANTS:
            await callback.answer(
                "Для этой карточки уже существует Variant.",
                show_alert=True,
            )
            return

        await state.clear()

        await state.update_data(
            offer_id=offer_id,
            edit_variant=False,
        )

        if callback.message:
            await callback.message.answer(
                "Создание Variant.\n\n"
                "Сначала введи название Variant на русском:",
                reply_markup=self.cancel_keyboard(),
            )

        await state.set_state(
            VariantStates.waiting_title_ru
        )

        await callback.answer()

    # ========================================================
    # VARIANT TITLE RU
    # ========================================================

    async def receive_title_ru(
        self,
        message: Message,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            message.from_user.id
            if message.from_user
            else None
        ):
            return

        value = (message.text or "").strip()

        if not value:
            await message.answer(
                "Название RU не может быть пустым."
            )
            return

        if len(value) > MAX_TITLE_LENGTH:
            await message.answer(
                "Название слишком длинное."
            )
            return

        await state.update_data(
            title_ru=value,
        )

        await message.answer(
            "Введите название EN:",
            reply_markup=self.cancel_keyboard(),
        )

        await state.set_state(
            VariantStates.waiting_title_en
        )

    # ========================================================
    # VARIANT TITLE EN
    # ========================================================

    async def receive_title_en(
        self,
        message: Message,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            message.from_user.id
            if message.from_user
            else None
        ):
            return

        value = (message.text or "").strip()

        if not value:
            await message.answer(
                "Название EN не может быть пустым."
            )
            return

        if len(value) > MAX_TITLE_LENGTH:
            await message.answer(
                "Название слишком длинное."
            )
            return

        data = await state.get_data()

        offer_id = data.get("offer_id")

        if offer_id is None:
            await state.clear()

            await message.answer(
                "Сессия потеряна."
            )
            return

        await message.answer(
            "Создаю Variant..."
        )

        try:
            result = (
                await self.ggsel.create_or_update_option(
                    offer_id=int(offer_id),
                    option_id=None,
                    title_ru=str(
                        data["title_ru"]
                    ),
                    title_en=value,
                    option_type="radio_button",
                    status="active",
                    has_splitted_products=False,
                    is_required=True,
                    is_price_modifier_hidden=False,
                    position=0,
                    comment_ru="",
                    comment_en="",
                )
            )
        except Exception:
            logger.exception(
                "Failed to create GGsel option"
            )

            await message.answer(
                "GGsel не принял создание Variant."
            )
            return

        option_id = self._extract_option_id(
            result
        )

        if option_id is None:
            try:
                options = await self.ggsel.get_options(
                    offer_id=int(offer_id),
                )
            except Exception:
                logger.exception(
                    "Failed to refresh options"
                )

                await message.answer(
                    "Variant создан, но не удалось "
                    "получить его ID."
                )
                return

            matching = [
                item
                for item in options
                if (
                    isinstance(item, dict)
                    and str(
                        item.get("title_ru") or ""
                    ) == str(
                        data["title_ru"]
                    )
                    and str(
                        item.get("title_en") or ""
                    ) == value
                )
            ]

            if matching:
                option_id = self.normalize_id(
                    matching[-1].get("id")
                )

        if option_id is None:
            await message.answer(
                "Variant создан, но его ID "
                "определить не удалось."
            )
            return

        await state.clear()

        await message.answer(
            "Variant создан.\n\n"
            f"RU: <b>{data['title_ru']}</b>\n"
            f"EN: <b>{value}</b>\n\n"
            "Теперь добавь первый Option.",
            reply_markup=self.cancel_keyboard(),
        )

        await state.update_data(
            offer_id=int(offer_id),
            option_id=option_id,
        )

        await state.set_state(
            OptionStates.waiting_title_ru
        )

    # ========================================================
    # RECEIVE HOURS / CREATE OPTION
    # ========================================================

    async def receive_hours(
        self,
        message: Message,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            message.from_user.id
            if message.from_user
            else None
        ):
            return

        try:
            hours = self.parse_positive_int(
                message.text or "",
                "Количество часов",
            )
        except ValueError as exc:
            await message.answer(str(exc))
            return

        if hours > MAX_HOURS:
            await message.answer(
                "Слишком большое количество часов."
            )
            return

        data = await state.get_data()
        print(data)


        try:
            offer_id = int(
                data["offer_id"]
            )

            option_id = int(
                data["option_id"]
            )

            price = Decimal(
                str(data["option_price"])
            )

            title_ru = str(
                data["option_title_ru"]
            )

            title_en = str(
                data["option_title_en"]
            )

        except (
            KeyError,
            TypeError,
            ValueError,
            InvalidOperation,
        ):
            await state.clear()

            await message.answer(
                "Сессия создания option потеряна."
            )
            return

        base_price = data.get("option_base_price")
        if base_price is None:
            raise ValueError

        sell_price, impact_type = self.calculate_price_modifier(
            base_price=Decimal(str(base_price)),
            final_price=price,
        )

        try:
            container = await self.ggsel.get_option(
                offer_id=offer_id,
                option_id=option_id,
            )
            print(f"{container=}")
        except Exception:
            logger.exception(
                "Failed to get Variant container"
            )

            await message.answer(
                "Не удалось получить Variant."
            )
            return

        variants = self.get_variants(
            container
        )
        logger.info(f"{variants=}")
        if len(variants) >= MAX_OPTIONS:
            await message.answer(
                f"В этом Variant уже создано "
                f"{MAX_OPTIONS} options."
            )
            return

        is_default = len(variants) == 0
        position = len(variants)

        await message.answer(
            "Сохраняю option на GGsel..."
        )

        try:
            result = (
                await self.ggsel.create_or_update_variant(
                    offer_id=offer_id,
                    option_id=option_id,
                    variant_id=None,
                    title_ru=title_ru,
                    title_en=title_en,
                    price=sell_price,
                    discount_type="fixed",
                    impact_type=impact_type,
                    is_default=is_default,
                    status="active",
                    position=position,
                )
            )
        except Exception:
            logger.exception(
                "Failed to create GGsel variant"
            )

            await message.answer(
                "GGsel не принял option."
            )
            return

        response_data = (
            result.get("data")
            if isinstance(result, dict)
            else None
        )

        if not isinstance(
            response_data,
            list,
        ) or not response_data:
            await message.answer(
                "GGsel создал option, но "
                "не вернул её данные."
            )
            return

        created_variant = response_data[0]

        if not isinstance(
            created_variant,
            dict,
        ):
            await message.answer(
                "GGsel вернул некорректные "
                "данные option."
            )
            return

        actual_variant_id = self.normalize_id(
            created_variant.get("id")
        )

        if actual_variant_id is None:
            await message.answer(
                "GGsel создал option, но "
                "не вернул корректный ID."
            )
            return

        try:
            game = (
                await self.db.get_game_by_ggsel_product(
                    ggsel_product_id=offer_id,
                )
            )
        except Exception:
            logger.exception(
                "Failed to get mapping"
            )

            await message.answer(
                "Option создана на GGsel, но "
                "mapping не удалось получить."
            )
            return

        if game is None:
            await message.answer(
                "Mapping GGsel → Kosell не найден."
            )
            return

        try:
            actual_price = Decimal(
                str(
                    created_variant.get("price")
                    if created_variant.get(
                        "price"
                    ) is not None
                    else price
                )
            )
        except (
            InvalidOperation,
            ValueError,
            TypeError,
        ):
            await message.answer(
                "GGsel вернул некорректную цену."
            )
            return

        try:
            offer = await self.ggsel.get_offer(
                offer_id=offer_id,
            )

            offer_data = offer.get("data")

            if not isinstance(offer_data, dict):
                raise ValueError(
                    "GGsel offer response does not contain data"
                )

            base_price = Decimal(
                str(offer_data["price"])
            )

        except Exception:
            logger.exception(
                "Failed to get GGsel base price: offer_id=%s",
                offer_id,
            )

            await message.answer(
                "Option создана на GGsel, "
                "но не удалось получить базовую цену товара."
            )
            return

        # В БД храним итоговую цену продажи, а не модификатор GGsel.
        final_price = price

        try:
            await self.db.upsert_rental_variant(
                game_id=int(game["id"]),
                ggsel_product_id=offer_id,
                ggsel_variant_id=actual_variant_id,
                hours=hours,
                price_rub=float(final_price),
            )
            await self.ggsel.update_option_visibility(
                offer_id=offer_id,
                option_id=option_id,
                status="active",
            )
        except Exception:
            logger.exception(
                "Failed to save rental variant"
            )

            await message.answer(
                "Option создана на GGsel, но "
                "не удалось сохранить её в БД."
            )
            return

        await state.clear()

        await message.answer(
            "Option сохранён.\n\n"
            f"RU: <b>{title_ru}</b>\n"
            f"EN: <b>{title_en}</b>\n"
            f"Цена: <b>{actual_price:g} ₽</b>\n"
            f"Время: <b>{hours} ч.</b>\n"
            f"Option ID: "
            f"<code>{actual_variant_id}</code>\n\n"
            f"Options: "
            f"<b>{len(variants) + 1}/"
            f"{MAX_OPTIONS}</b>"
        )

        await self.send_option_message(
            message=message,
            offer_id=offer_id,
            option_id=option_id,
        )

    # ========================================================
    # SEND OPTION
    # ========================================================

    async def send_option_message(
        self,
        *,
        message: Message,
        offer_id: int,
        option_id: int,
    ) -> None:
        try:
            option = await self.ggsel.get_option(
                offer_id=offer_id,
                option_id=option_id,
            )
        except Exception:
            logger.exception(
                "Failed to get Variant container"
            )
            return

        variants = self.get_variants(
            option
        )

        text = (
            f"<b>{self.option_title(option)}</b>\n\n"
            f"Variant ID: "
            f"<code>{option_id}</code>\n"
            f"Options: "
            f"<b>{len(variants)}/{MAX_OPTIONS}</b>\n\n"
        )

        if not variants:
            text += (
                "Options пока нет.\n\n"
                "Добавь первый option."
            )

        else:
            text += "Список options:\n\n"

            offer = await self.ggsel.get_offer(
                offer_id=offer_id
            )
            offer_data = offer.get("data")

            if not isinstance(offer_data, dict):
                raise ValueError(
                    "GGsel offer response не содержит data"
                )

            base_price = Decimal(
                str(offer_data["price"])
            )

            for index, variant in enumerate(
                variants,
                start=1,
            ):
                title = self.variant_title(
                    variant
                )

                variant_id = self.normalize_id(
                    variant.get("id")
                )

                final_price = self.get_variant_final_price(
                    base_price=base_price,
                    variant=variant,
                )

                text += (
                    f"{index}. "
                    f"<b>{title}</b>\n"
                    f"Цена: "
                    f"<b>{final_price:g} ₽</b>\n"
                )

                if variant_id is not None:
                    text += (
                        f"ID: "
                        f"<code>{variant_id}</code>\n"
                    )

                text += "\n"

        await message.answer(
            text,
            reply_markup=self.option_keyboard(
                offer_id=offer_id,
                option_id=option_id,
                variants=variants,
            ),
        )


    async def restore_ggsel_product(
            self,
            callback: CallbackQuery,
    ):
        product_id = int(callback.data.split(":", 1)[1])

        try:
            await self.ggsel.activate_products([product_id])
        except Exception:
            await callback.answer(
                "Не удалось вернуть товар в продажу",
                show_alert=True,
            )
            return

        await callback.answer("Товар возвращён в продажу")

        message = callback.message

        if message:
            await message.edit_text(
                message.text + (
                    f"\n\n✅ Товар <code>{product_id}</code> "
                    "возвращён в продажу (через некоторое время отбразится.)."
                ),
                parse_mode="HTML",
            )


    # ========================================================
    # CANCEL
    # ========================================================

    async def cancel(
        self,
        callback: CallbackQuery,
        state: FSMContext,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            return

        await state.clear()

        if callback.message:
            await callback.message.answer(
                "Операция отменена."
            )

        await callback.answer()

    # ========================================================
    # NO ACTION
    # ========================================================

    async def no_action(
        self,
        callback: CallbackQuery,
    ) -> None:
        if not self.is_admin(
            callback.from_user.id
            if callback.from_user
            else None
        ):
            return

        await callback.answer(
            "Максимум 5 options.",
            show_alert=True,
        )

    async def disable_ggsel_product(
            self,
            callback: CallbackQuery,
    ):
        offer_id = int(callback.data.split(":")[-1])

        try:
            response = await self.ggsel.hide_products(
                products=[{"id_goods": offer_id}],
                bot=callback.bot,
                notify=False
            )

            if response is not None and response.status_code >= 400:
                raise ValueError(
                    f"GGsel batch pause error: {response.status_code}"
                )

        except Exception:
            logger.exception(
                "Failed to disable GGsel offer %s",
                offer_id,
            )

            await callback.answer(
                "Не удалось снять товар с продажи",
                show_alert=True,
            )
            return

        await callback.answer(
            "Товар снят с продажи",
        )

    async def activate_ggsel_product(
            self,
            callback: CallbackQuery,
    ):
        offer_id = int(callback.data.split(":")[-1])

        try:
            response = await self.ggsel.activate_products(
                [offer_id]
            )

            if response is not None and response.status_code >= 400:
                raise ValueError(
                    f"GGsel batch activate error: {response.status_code}"
                )

        except Exception:
            logger.exception(
                "Failed to activate GGsel offer %s",
                offer_id,
            )

            await callback.answer(
                "Не удалось выставить товар на продажу",
                show_alert=True,
            )
            return

        await callback.answer(
            "Товар выставлен на продажу",
        )
    # ========================================================
    # EXTRACT OPTION ID
    # ========================================================

    @staticmethod
    def _extract_option_id(
        result: Any,
    ) -> int | None:
        if not isinstance(
            result,
            dict,
        ):
            return None

        candidates: list[Any] = [
            result.get("id"),
            result.get("option_id"),
        ]

        data = result.get("data")

        if isinstance(data, dict):
            candidates.extend(
                [
                    data.get("id"),
                    data.get("option_id"),
                ]
            )

        elif isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    candidates.extend(
                        [
                            item.get("id"),
                            item.get("option_id"),
                        ]
                    )

        for candidate in candidates:
            normalized = GgselBot.normalize_id(
                candidate
            )

            if normalized is not None:
                return normalized

        return None

    # ========================================================
    # REGISTER
    # ========================================================

    def register(
        self,
        dispatcher: Dispatcher,
    ) -> None:

        # ----------------------------------------------------
        # Mapping
        # ----------------------------------------------------

        dispatcher.message.register(
            self.start_mapping,
            Command("mapping"),
        )

        dispatcher.message.register(
            self.handler_start,
            Command("start")
        )

        dispatcher.message.register(
            self.receive_ggsel_id,
            MappingStates.waiting_ggsel_id,
        )

        dispatcher.message.register(
            self.receive_kosell_product_id,
            MappingStates.waiting_kosell_product_id,
        )

        dispatcher.callback_query.register(
            self.disable_ggsel_product,
            F.data.startswith("ggsel:disable:"),
        )

        dispatcher.callback_query.register(
            self.activate_ggsel_product,
            F.data.startswith("ggsel:activate:"),
        )

        # ----------------------------------------------------
        # Variant creation
        # ----------------------------------------------------

        dispatcher.message.register(
            self.receive_title_ru,
            VariantStates.waiting_title_ru,
        )

        dispatcher.message.register(
            self.receive_title_en,
            VariantStates.waiting_title_en,
        )


        # ----------------------------------------------------
        # Option creation / editing
        # ----------------------------------------------------

        dispatcher.message.register(
            self.receive_option_title_ru,
            OptionStates.waiting_title_ru,
        )

        dispatcher.message.register(
            self.receive_option_title_en,
            OptionStates.waiting_title_en,
        )

        dispatcher.message.register(
            self.receive_price,
            OptionStates.waiting_price,
        )

        dispatcher.message.register(
            self.receive_hours,
            OptionStates.waiting_hours,
        )

        # ----------------------------------------------------
        # Common callbacks
        # ----------------------------------------------------

        dispatcher.callback_query.register(
            self.no_action,
            F.data == "ggsel:no_action",
        )

        dispatcher.callback_query.register(
            self.cancel,
            F.data == "ggsel:cancel",
        )

        dispatcher.callback_query.register(
            self.restore_ggsel_product,
            F.data.startswith("ggsel_restore:")
        )

        # ----------------------------------------------------
        # Create Variant
        # ----------------------------------------------------

        dispatcher.callback_query.register(
            self.start_add_variant,
            F.data.startswith(
                "ggsel:add_variant:"
            ),
        )

        # ----------------------------------------------------
        # Create Option
        # ----------------------------------------------------

        dispatcher.callback_query.register(
            self.start_add_option,
            F.data.startswith(
                "ggsel:add_option:"
            ),
        )

        # ----------------------------------------------------
        # Edit Option
        # ----------------------------------------------------

        dispatcher.callback_query.register(
            self.edit_option,
            F.data.startswith(
                "ggsel:edit_option:"
            ),
        )

        dispatcher.callback_query.register(
            self.edit_option_title_ru,
            F.data.startswith(
                "ggsel:edit_option_title_ru:"
            ),
        )

        dispatcher.callback_query.register(
            self.edit_option_title_en,
            F.data.startswith(
                "ggsel:edit_option_title_en:"
            ),
        )

        dispatcher.callback_query.register(
            self.edit_option_price,
            F.data.startswith(
                "ggsel:edit_option_price:"
            ),
        )

        dispatcher.callback_query.register(
            self.edit_option_status,
            F.data.startswith(
                "ggsel:edit_option_status:"
            ),
        )

        dispatcher.callback_query.register(
            self.set_option_status,
            F.data.startswith(
                "ggsel:set_option_status:"
            ),
        )


        # ----------------------------------------------------
        # Offer
        # ----------------------------------------------------

        dispatcher.callback_query.register(
            self.show_offer,
            F.data.startswith(
                "ggsel:offer:"
            ),
        )

        # ----------------------------------------------------
        # Variant / Option list
        # ----------------------------------------------------

        dispatcher.callback_query.register(
            self.show_variant,
            F.data.startswith(
                "ggsel:variant:"
            ),
        )

        dispatcher.callback_query.register(
            self.start_edit_option_hours,
            F.data.startswith(
                "ggsel:edit_option_hours:"
            ),
        )

        dispatcher.message.register(
            self.receive_edit_option_hours,
            OptionStates.editing_hours,
        )