from __future__ import annotations

import argparse
import asyncio
import logging

from config import load_settings
from db import Database


logging.basicConfig(
    level=logging.INFO,
    format=(
        "%(asctime)s | "
        "%(levelname)s | "
        "%(message)s"
    ),
)

logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Create GGsel -> Kosell product mapping"
        ),
    )

    parser.add_argument(
        "--ggsel-id",
        type=int,
        required=True,
        help="ID_D карточки товара на GGsel",
    )

    parser.add_argument(
        "--kosell-id",
        type=int,
        required=True,
        help="product_id товара в Kosell",
    )

    parser.add_argument(
        "--name",
        type=str,
        required=True,
        help="Название товара/игры",
    )

    parser.add_argument(
        "--hours",
        type=int,
        required=True,
        help="Продолжительность аренды в часах",
    )

    return parser.parse_args()


async def main() -> None:
    args = parse_args()

    if args.ggsel_id <= 0:
        raise ValueError(
            "GGsel ID должен быть положительным"
        )

    if args.kosell_id <= 0:
        raise ValueError(
            "Kosell ID должен быть положительным"
        )

    if not args.name.strip():
        raise ValueError(
            "Название товара не может быть пустым"
        )

    if args.hours <= 0:
        raise ValueError(
            "Продолжительность аренды должна быть "
            "больше нуля"
        )

    settings = load_settings()

    db = Database(
        settings.database_path,
    )

    try:
        await db.connect()

        # Проверяем, не существует ли уже такая
        # GGsel-карточка.
        existing_game = (
            await db.get_game_by_ggsel_product(
                ggsel_product_id=args.ggsel_id,
            )
        )

        if existing_game is not None:
            raise RuntimeError(
                "Для GGsel ID "
                f"{args.ggsel_id} уже существует mapping: "
                f"game_id={existing_game['id']}, "
                f"name={existing_game['name']!r}, "
                f"kosell_product_id="
                f"{existing_game['kosell_product_id']}, "
                f"duration_hours="
                f"{existing_game['duration_hours']}"
            )

        game_id = await db.create_game(
            name=args.name.strip(),
            kosell_product_id=args.kosell_id,
            duration_hours=args.hours,
        )

        await db.create_offer_mapping(
            ggsel_product_id=args.ggsel_id,
            game_id=game_id,
        )

        logger.info(
            "Mapping successfully created:"
        )

        logger.info(
            "GGsel product ID: %s",
            args.ggsel_id,
        )

        logger.info(
            "Game ID: %s",
            game_id,
        )

        logger.info(
            "Kosell product ID: %s",
            args.kosell_id,
        )

        logger.info(
            "Rental duration: %s hours",
            args.hours,
        )

    finally:
        await db.close()


if __name__ == "__main__":
    asyncio.run(main())