from __future__ import annotations

import asyncio
import logging

import uvicorn
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand
from fastapi import FastAPI

from config import load_settings
from db import Database
from ggsel.ggsel_session import GgselClient
from ggsel.webhook import GgselWebhook
from ggsel.webhook_message import GgselMessageWebhook
from kosell.kosell_session import KosellClient
from mapping_aiogram import GgselBot
from services.check_no_account import check_no_account_loop
from services.sale_processor import SaleProcessor

logging.basicConfig(
    level=logging.INFO,
    format=(
        "%(asctime)s | "
        "%(levelname)s | "
        "%(name)s | "
        "%(message)s"
    ),
)

logger = logging.getLogger(__name__)


async def main() -> None:
    settings = load_settings()

    db = Database(
        settings.database_path,
    )

    ggsel = GgselClient(
        api_key=settings.ggsel_api_key,
        seller_id=settings.ggsel_seller_id,
        settings=settings
    )

    kosell = KosellClient(
        api_key=settings.kosell_api_key,
    )

    bot = Bot(
        token=settings.telegram_bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        # session=AiohttpSession(proxy="socks5://w4QNAW:RWhs7o@85.195.81.167:12312")
    )
    await bot.set_my_commands([
        BotCommand(command="start", description="Запустить бота"),
        BotCommand(command="mapping", description="Связка карточек")
    ])

    dispatcher = Dispatcher(
        storage=MemoryStorage(),
    )

    app = FastAPI(
        docs_url=None,
        redoc_url=None,
    )

    try:
        # ---------------------------------------------------------
        # DATABASE
        # ---------------------------------------------------------

        await db.connect()

        logger.info(
            "Database connected",
        )

        # ---------------------------------------------------------
        # SERVICES
        # ---------------------------------------------------------

        processor = SaleProcessor(
            db=db,
            kosell=kosell,
            ggsel=ggsel,
            bot=bot,
            admin_id=settings.telegram_admin_id
        )

        ggsel_bot = GgselBot(
            ggsel=ggsel,
            kosell=kosell,
            db=db
        )

        ggsel_bot.register(
            dispatcher,
        )

        # ---------------------------------------------------------
        # GGSEL WEBHOOKS
        # ---------------------------------------------------------

        webhook = GgselWebhook(
            db=db,
            processor=processor
        )

        webhook_message = GgselMessageWebhook(
            db=db,
            ggsel=ggsel,
            kosell=kosell,
        )

        app.include_router(
            webhook.router,
        )

        app.include_router(
            webhook_message.router,
        )

        # ---------------------------------------------------------
        # HEALTHCHECK
        # ---------------------------------------------------------

        @app.get("/health")
        async def health() -> dict[str, str]:
            return {
                "status": "ok",
            }

        # ---------------------------------------------------------
        # UVICORN
        # ---------------------------------------------------------

        uvicorn_config = uvicorn.Config(
            app,
            host=settings.webhook_host,
            port=settings.webhook_port,
            log_level="info",
        )

        server = uvicorn.Server(
            uvicorn_config,
        )

        # ---------------------------------------------------------
        # START BOTH SERVICES
        # ---------------------------------------------------------

        logger.info(
            "Starting GGsel webhook server on %s:%s",
            settings.webhook_host,
            settings.webhook_port,
        )

        logger.info(
            "Starting Telegram mapping bot",
        )

        await asyncio.gather(
            server.serve(),
            dispatcher.start_polling(
                bot,
                allowed_updates=dispatcher.resolve_used_update_types(),
            ),
            check_no_account_loop(ggsel=ggsel, kosell=kosell, db=db, bot=bot),
        )

    except asyncio.CancelledError:
        logger.info(
            "Application shutdown requested",
        )
        raise

    except Exception:
        logger.exception(
            "Application crashed",
        )
        raise

    finally:
        logger.info(
            "Shutting down application",
        )

        await bot.session.close()
        await ggsel.close()
        await kosell.close()
        await db.close()

        logger.info(
            "Application shutdown completed",
        )


if __name__ == "__main__":
    asyncio.run(main())