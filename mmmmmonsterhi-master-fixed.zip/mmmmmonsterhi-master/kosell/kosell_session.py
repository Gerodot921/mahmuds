from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

class KosellClient:
    BASE_URL = "https://www.kosell.store"

    def __init__(
        self,
        *,
        api_key: str,
    ) -> None:
        self.client = httpx.AsyncClient(
            base_url=self.BASE_URL,
            headers={
                "Accept": "application/json",
                "X-API-Key": api_key,
            },
            timeout=httpx.Timeout(10.0),
        )

    async def close(self) -> None:
        await self.client.aclose()

    async def get_balance(self) -> dict[str, Any]:
        response = await self.client.get(
            "/api/v1/account/balance",
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, dict):
            raise ValueError(
                "Unexpected Kosell balance response"
            )

        return payload

    async def search(
        self,
        *,
        search: str | None = None,
        currency: str = "RUB",
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "currency": currency,
        }

        if search:
            params["search"] = search

        response = await self.client.get(
            "/api/v1/rental/products",
            params=params,
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, list):
            raise ValueError(
                "Unexpected Kosell search response"
            )

        return payload

    async def calculate_price(
            self,
            *,
            product_id: int,
            hours: int,
    ) -> dict[str, Any]:
        max_attempts = 3

        for attempt in range(1, max_attempts + 1):
            try:
                response = await self.client.post(
                    "/api/v1/rental/calculate-price",
                    json={
                        "product_id": product_id,
                        "hours": hours,
                    },
                )

                if response.status_code in {
                    502,
                    503,
                    504,
                }:
                    if attempt < max_attempts:
                        delay = 2 ** (attempt - 1)

                        logger.warning(
                            "Kosell calculate-price returned %s: "
                            "attempt=%s/%s product=%s hours=%s "
                            "retry_in=%ss",
                            response.status_code,
                            attempt,
                            max_attempts,
                            product_id,
                            hours,
                            delay,
                        )

                        await asyncio.sleep(delay)
                        continue

                    logger.error(
                        "Kosell calculate-price failed after "
                        "%s attempts: status=%s product=%s hours=%s",
                        max_attempts,
                        response.status_code,
                        product_id,
                        hours,
                    )

                response.raise_for_status()

                payload = response.json()

                if not isinstance(payload, dict):
                    raise ValueError(
                        "Unexpected Kosell calculate-price response"
                    )

                return payload

            except httpx.RequestError as exc:
                if attempt >= max_attempts:
                    logger.error(
                        "Kosell calculate-price network error "
                        "after %s attempts: product=%s hours=%s "
                        "error=%s",
                        max_attempts,
                        product_id,
                        hours,
                        exc,
                    )
                    raise

                delay = 2 ** (attempt - 1)

                logger.warning(
                    "Kosell calculate-price network error: "
                    "attempt=%s/%s product=%s hours=%s "
                    "retry_in=%ss error=%s",
                    attempt,
                    max_attempts,
                    product_id,
                    hours,
                    delay,
                    exc,
                )

                await asyncio.sleep(delay)

        raise RuntimeError(
            "Kosell calculate-price failed after retries"
        )

    async def rent(
        self,
        *,
        product_id: int,
        duration_hours: int,
        currency: str = "RUB",
    ) -> dict[str, Any]:
        """
        Create a rental.

        IMPORTANT:
        Do not automatically retry this request after a timeout.
        The remote server may have created the rental even though
        the client did not receive the response.
        """

        response = await self.client.post(
            "/api/v1/rental/rent",
            json={
                "product_id": product_id,
                "duration_hours": duration_hours,
                "currency": currency,
            },
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, dict):
            raise ValueError(
                "Unexpected Kosell rent response"
            )

        return payload

    async def get_credentials(
        self,
        *,
        rental_uid: str,
    ) -> dict[str, str]:
        response = await self.client.get(
            f"/api/v1/rental/{rental_uid}/credentials",
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, dict):
            raise ValueError(
                "Unexpected credentials response"
            )

        return payload

    async def get_steam_guard_code(
        self,
        *,
        rental_uid: str,
    ) -> dict[str, Any]:
        response = await self.client.get(
            f"/api/v1/rental/{rental_uid}/code",
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, dict):
            raise ValueError(
                "Unexpected Steam Guard response"
            )

        return payload

    from typing import Any

    async def get_rental_products(
            self,
    ) -> list[dict[str, Any]]:
        response = await self.client.get(
            "/api/rentals/products",
        )
        response.raise_for_status()

        result = response.json()

        if not isinstance(result, list):
            raise ValueError(
                "Kosell API вернул некорректный список rental products"
            )

        products: list[dict[str, Any]] = []

        for item in result:
            if not isinstance(item, dict):
                continue

            product_id = item.get("id")
            name = item.get("name")

            if product_id is None or not name:
                continue

            try:
                product_id = int(product_id)
            except (TypeError, ValueError):
                continue

            products.append(
                {
                    **item,
                    "id": product_id,
                    "name": str(name),
                }
            )

        return products