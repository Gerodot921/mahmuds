from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException

from db import Database
from ggsel.ggsel_session import GgselClient
from kosell.kosell_session import KosellClient

logger = logging.getLogger(__name__)


class GgselMessageWebhook:
    def __init__(
        self,
        *,
        db: Database,
        ggsel: GgselClient,
        kosell: KosellClient,
    ) -> None:
        self.db = db
        self.ggsel = ggsel
        self.kosell = kosell

        self.router = APIRouter()

        self.router.add_api_route(
            "/webhook/ggsel/message",
            self.handle,
            methods=["POST"],
        )

    async def handle(
        self,
        payload: dict[str, Any],
    ) -> dict[str, bool]:
        logger.info(
            "GGsel sale webhook Message payload: %r",
            payload,
        )

        invoice_id = payload.get("InvoiceId")
        message = payload.get("Message")

        if invoice_id is None:
            raise HTTPException(
                status_code=400,
                detail="Missing InvoiceId",
            )

        if not isinstance(message, str):
            raise HTTPException(
                status_code=400,
                detail="Invalid Message",
            )

        invoice_id = str(invoice_id)

        normalized = " ".join(
            message.strip().lower().split()
        )

        logger.info(
            "GGsel buyer message: invoice=%s message=%r",
            invoice_id,
            message[:500],
        )

        sale = await self.db.get_sale(
            invoice_id=invoice_id,
        )

        if sale is None:
            logger.warning(
                "Message for unknown invoice: %s",
                invoice_id,
            )
            return {"ok": True}

        if normalized in {
            "код",
            "code",
        }:
            await self.db.add_event(
                event_type="CODE_REQUESTED",
                sale_id=sale["id"],
                payload={
                    "invoice_id": invoice_id,
                    "debate_id": payload.get("DebateId"),
                    "message_id": payload.get("MessageId"),
                    "message": message[:500],
                },
            )
            rental = await self.db.get_rental_by_invoice_id(
                invoice_id=int(invoice_id),
            )

            if rental is None:
                logger.error(
                    "Rental not found: invoice=%s",
                    invoice_id,
                )
                raise HTTPException(
                    status_code=400,
                    detail="Missing rental for invoice",
                )

            rental_uid = rental["kosell_rental_uid"]
            code_response = await self.kosell.get_steam_guard_code(
                rental_uid=rental_uid,
            )
            print(code_response)
            steam_guard_code = code_response.get("code")
            logger.info("Steam Guard code: %s", steam_guard_code)

            if not steam_guard_code:
                logger.warning(
                    "Steam Guard code unavailable: invoice=%s",
                    invoice_id,
                )

                await self.db.add_event(
                    event_type="STEAM_GUARD_UNAVAILABLE",
                    sale_id=sale["id"],
                    payload={
                        "invoice_id": invoice_id,
                    },
                )

                await self.ggsel.send_message(
                    debate_id=int(invoice_id),
                    message=(
                        "Steam Guard код пока недоступен. "
                        "Попробуйте запросить код ещё раз через несколько секунд."
                    ),
                )

                return {"ok": True}

            await self.ggsel.send_message(
                debate_id=int(invoice_id),
                message=f"💡 Steam Guard код: {steam_guard_code}\n\n💎 Оставьте пожалуйста отзыв 💎",
            )

            logger.info(
                "Steam Guard code requested: invoice=%s",
                invoice_id,
            )

        return {"ok": True}