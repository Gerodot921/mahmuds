from __future__ import annotations

import hashlib
import logging
import time
from decimal import Decimal
from typing import Any, Literal

import httpx
from aiogram import Bot

from config import Settings
from keyboard import get_restore_keyboard

logger = logging.getLogger("ggsel")

def generate_sign(api_key: str, timestamp: str) -> str:
    message = f"{api_key}{timestamp}"
    return hashlib.sha256(message.encode("utf-8")).hexdigest()


class GgselClient:
    BASE_URL = "https://seller.ggsel.com"

    def __init__(
        self,
        *,
        api_key: str,
        seller_id: str,
        settings: Settings,
    ) -> None:
        self.api_key = api_key
        self.seller_id = seller_id
        self.settings = settings
        self.client = httpx.AsyncClient(
            base_url=self.BASE_URL,
            headers={
                "Accept": "application/json",
                "Authorization": api_key,
            },
            timeout=httpx.Timeout(10.0),
        )

    async def close(self) -> None:
        await self.client.aclose()

    async def get_token(self) -> str:
        timestamp = str(int(time.time()))

        response = await self.client.post(
            f"/api_sellers/api/apilogin",
            json={
                "seller_id": self.seller_id,
                "timestamp": timestamp,
                "sign": generate_sign(self.api_key, timestamp),
            },
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            timeout=15.0,
        )

        response.raise_for_status()

        data = response.json()

        token = data.get("token")
        if not token:
            raise RuntimeError(f"GGsel не вернул token: {data}")

        return token

    async def send_message(self, debate_id: int, message: str) -> bool:
        """Send a message to a chat."""

        logger.info("SEND_MESSAGE debate_id: %s", debate_id)
        response = await self.client.post(
            "/api_sellers/api/debates/v2",
            json={
                "message": message,
            },
            params={
                "id_i": debate_id,
                "token": await self.get_token()
            }
        )

        response.raise_for_status()
        return True

    async def get_order_info(
            self,
            invoice_id: int | str,
            *,
            locale: str = "ru",
    ) -> dict[str, Any]:
        response = await self.client.get(
            f"/api_sellers/api/purchase/info/{invoice_id}",
            headers={
                "locale": locale,
            },
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, dict):
            raise ValueError(
                "Unexpected GGsel order info response"
            )

        return payload

    async def get_offer(
        self,
        *,
        offer_id: int,
    ) -> dict[str, Any]:
        response = await self.client.get(
            f"/api_sellers/v2/offers/{offer_id}"
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, dict):
            raise ValueError(
                "Некорректный ответ GGsel при получении карточки"
            )

        return payload

    async def get_option(
        self,
        *,
        offer_id: int,
        option_id: int,
    ) -> dict[str, Any]:
        response = await self.client.get(
            (
                f"/api_sellers/v2/offers/"
                f"{offer_id}/options/{option_id}"
            ),
            headers={
                "locale": "ru",
            },
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, dict):
            raise ValueError(
                "Некорректный ответ GGsel при получении option"
            )

        data = payload.get("data")

        if not isinstance(data, dict):
            raise ValueError(
                "GGsel option response не содержит data"
            )

        return data

    async def create_or_update_variant(
            self,
            *,
            offer_id: int,
            option_id: int,
            variant_id: int | None,
            title_ru: str,
            title_en: str,
            price: Decimal,
            discount_type: str,
            impact_type: str,
            is_default: bool,
            status: str,
            position: int,
    ) -> dict[str, Any]:

        variant: dict[str, Any] = {
            "title_ru": title_ru,
            "title_en": title_en,
            "price": float(price),
            "discount_type": discount_type,
            "impact_type": impact_type,
            "is_default": is_default,
            "status": status,
            "position": position,
        }
        logger.info("variant TO created/updated %s", variant)

        if variant_id is not None:
            variant["id"] = variant_id

        payload = {
            "variants": [variant],
        }

        response = await self.client.post(
            (
                f"/api_sellers/v2/offers/"
                f"{offer_id}/options/"
                f"{option_id}/variants"
            ),
            json=payload,
        )

        if response.status_code >= 400:
            logger.error(
                "GGsel variant API error: "
                "status=%s body=%s payload=%r",
                response.status_code,
                response.text,
                payload,
            )
        if response.is_error:
            logger.error(
                "GGsel variant API error: "
                "status=%s body=%s payload=%r",
                response.status_code,
                response.text,
                payload,
            )
            response.raise_for_status()

        result = response.json()

        if not isinstance(result, dict):
            raise ValueError(
                "Некорректный ответ GGsel "
                "при создании/обновлении variant"
            )

        logger.info(
            "GGsel variant created/updated: %r",
            result,
        )

        return result

    async def delete_variant(
            self,
            *,
            offer_id: int,
            option_id: int,
            variant_id: int,
            delete_all: bool = False
    ) -> dict[str, Any]:

        response = await self.client.request(
            "DELETE",
            (
                f"/api_sellers/v2/offers/"
                f"{offer_id}/options/"
                f"{option_id}/variants"
            ),
            json={
                "option_variant_ids": [
                    variant_id,
                ],
                "delete_all": "true" if delete_all else "false",
            },
        )

        response.raise_for_status()

        result = response.json()

        if not isinstance(result, dict):
            raise ValueError(
                "Некорректный ответ GGsel "
                "при удалении variant"
            )

        return result

    async def get_options(
            self,
            *,
            offer_id: int,
    ) -> list[dict[str, Any]]:
        response = await self.client.get(
            f"/api_sellers/v2/offers/{offer_id}/options",
            headers={
                "locale": "ru",
            },
        )

        response.raise_for_status()

        payload = response.json()

        if not isinstance(payload, dict):
            raise ValueError(
                "GGsel options response должен быть объектом"
            )

        data = payload.get("data")

        if not isinstance(data, list):
            raise ValueError(
                "GGsel options response не содержит "
                "корректный data"
            )

        options: list[dict[str, Any]] = []

        for item in data:
            if not isinstance(item, dict):
                continue

            options.append(item)

        return options

    async def create_or_update_option(
            self,
            *,
            offer_id: int,
            option_id: int | None,
            title_ru: str,
            title_en: str,
            option_type: str = "radio_button",
            status: str = "active",
            has_splitted_products: bool = False,
            is_required: bool = True,
            is_price_modifier_hidden: bool = False,
            position: int = 0,
            comment_ru: str = "",
            comment_en: str = "",
    ) -> dict[str, Any]:
        if option_type not in {
            "text",
            "multiline_text",
            "check_box",
            "radio_button",
        }:
            raise ValueError(
                f"Некорректный тип GGsel option: {option_type}"
            )

        if status not in {
            "active",
            "archived",
            "hidden",
        }:
            raise ValueError(
                f"Некорректный status GGsel option: {status}"
            )

        option: dict[str, Any] = {
            "type": option_type,
            "status": status,
            "has_splitted_products": has_splitted_products,
            "title_ru": title_ru,
            "title_en": title_en,
            "comment_ru": comment_ru,
            "comment_en": comment_en,
            "is_required": is_required,
            "is_price_modifier_hidden": is_price_modifier_hidden,
            "position": position,
        }

        if option_id is not None:
            option["id"] = option_id

        response = await self.client.post(
            f"/api_sellers/v2/offers/{offer_id}/options",
            json={
                "options": [option],
            },
        )

        response.raise_for_status()

        result = response.json()

        if not isinstance(result, dict):
            raise ValueError(
                "Некорректный ответ GGsel "
                "при создании/обновлении option"
            )

        return result

    async def update_option_visibility(
            self,
            *,
            offer_id: int,
            option_id: int,
            status: Literal["active", "hidden"] = "active",
    ) -> dict[str, Any]:
        payload = {
            "options": [
                {
                    "id": option_id,
                    "status": status,
                }
            ]
        }

        response = await self.client.patch(
            (
                f"/api_sellers/v2/offers/"
                f"{offer_id}/options/batch_visibility"
            ),
            json=payload,
        )

        if response.status_code >= 400:
            logger.error(
                "GGsel option visibility error: "
                "status=%s body=%s payload=%r",
                response.status_code,
                response.text,
                payload,
            )

        response.raise_for_status()

        result = response.json()

        if not isinstance(result, dict):
            raise ValueError(
                "Некорректный ответ GGsel "
                "при изменении visibility option"
            )

        logger.info(
            "GGsel option visibility updated: "
            "offer_id=%s option_id=%s status=%s",
            offer_id,
            option_id,
            status,
        )

        return result

    from typing import Any, Literal

    async def update_variant_visibility(
            self,
            *,
            offer_id: int,
            option_id: int,
            variant_id: int,
            status: Literal["active", "hidden"] = "active",
    ) -> dict[str, Any]:
        if offer_id <= 0:
            raise ValueError("offer_id должен быть положительным")

        if option_id <= 0:
            raise ValueError("option_id должен быть положительным")

        if variant_id <= 0:
            raise ValueError("variant_id должен быть положительным")

        payload = {
            "variants": [
                {
                    "id": variant_id,
                    "status": status,
                }
            ]
        }

        response = await self.client.patch(
            (
                f"/api_sellers/v2/offers/"
                f"{offer_id}/options/"
                f"{option_id}/variants/batch_visibility"
            ),
            json=payload,
        )

        if response.status_code >= 400:
            logger.error(
                "GGsel variant visibility error: "
                "status=%s body=%s payload=%r",
                response.status_code,
                response.text,
                payload,
            )

        response.raise_for_status()

        result = response.json()

        if not isinstance(result, dict):
            raise ValueError(
                "Некорректный ответ GGsel "
                "при изменении visibility variant"
            )

        logger.info(
            "GGsel variant visibility updated: "
            "offer_id=%s option_id=%s variant_id=%s status=%s",
            offer_id,
            option_id,
            variant_id,
            status,
        )

        return result

    async def get_my_sells(self) -> list[dict]:
        products = []
        page = 1
        count = 100

        while True:
            data = await self.client.get(
                "/api_sellers/api/products/list",
                params={
                    "page": page,
                    "count": count,
                    "token": await self.get_token()
                },
            )
            json_data = data.json()
            page_products = json_data.get("rows", [])

            if not page_products:
                break

            products.extend(page_products)

            if len(page_products) < count:
                break

            page += 1

        return products


    async def hide_products(self, products: list[dict], bot: Bot, notify=True):
        """
        Заглушка для будущего скрытия товаров на GGsel.
        """
        product_ids = [int(x.get("id_goods")) for x in products]
        payload = {
            "offer_ids": product_ids
        }

        res = await self.client.post(
            f"/api_sellers/v2/offers/batch_pause",
            json=payload
        )
        if res.status_code >= 400:
            raise ValueError("GGsel batch pause error")
        
        if notify:
            products_text = "\n".join(
                f"• {product.get('game_name', 'Неизвестная игра')} "
                f"(GGsel ID: <code>{product.get('id_goods')}</code>)"
                for product in products
            )

            await bot.send_message(
                chat_id=self.settings.telegram_admin_id,
                text=(
                    "⚠️ <b>Товары скрыты на GGsel</b>\n\n"
                    "Причина: на Kosell больше нет доступных аккаунтов для аренды.\n\n"
                    f"{products_text}"
                ),
                parse_mode="HTML",
                reply_markup=get_restore_keyboard(products),
            )

    async def show_products(self, products: list[dict], bot: Bot, notify=True):
        """
        Снимает паузу с товаров и активирует их на GGsel.
        """
        product_ids = [int(x.get("id_goods")) for x in products]

        payload = {
            "offer_ids": product_ids,
        }

        res = await self.client.post(
            "/api_sellers/v2/offers/batch_activate",
            json=payload,
        )

        if res.status_code >= 400:
            raise ValueError("GGsel batch resume error")

        if notify:
            products_text = "\n".join(
                f"• {product.get('game_name', 'Неизвестная игра')} "
                f"(GGsel ID: <code>{product.get('id_goods')}</code>)"
                for product in products
            )

            await bot.send_message(
                chat_id=self.settings.telegram_admin_id,
                text=(
                    "✅ <b>Товары активированы на GGsel</b>\n\n"
                    "Причина: на Kosell появились доступные аккаунты для аренды.\n\n"
                    f"{products_text}"
                ),
                parse_mode="HTML",
            )

    async def activate_products(self, product_ids: list[int], bot: Bot, notify=True):
        """
        Заглушка для возврата товаров в продажу на GGsel.
        """

        if not product_ids:
            return None

        payload = {
            "offer_ids": product_ids
        }

        return await self.client.post(
            "/api_sellers/v2/offers/batch_activate",
            json=payload,
        )