from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import APIRouter, HTTPException

from db import Database
from services.sale_processor import SaleProcessor

logger = logging.getLogger(__name__)


class GgselWebhook:
    def __init__(
        self,
        *,
        db: Database,
        processor: SaleProcessor,
    ) -> None:
        self.db = db
        self.processor = processor

        self.router = APIRouter()
        self.router.add_api_route(
            "/webhook/ggsel",
            self.handle,
            methods=["POST"],
        )

    async def handle(
        self,
        payload: dict[str, Any],
    ) -> dict[str, bool] | None:
        try:
            logger.info(
                "GGsel sale webhook payload: %r",
                payload,
            )
            invoice_id = payload.get("id_i")
            product_id = payload.get("id_d")
            signature = payload.get("SHA256")

            if invoice_id is None:
                logger.error(
                    "GGsel webhook missing id_i. Payload=%r",
                    payload,
                )
                raise HTTPException(
                    status_code=400,
                    detail="Missing id_i",
                )

            if product_id is None:
                logger.error(
                    "GGsel webhook missing ID_D. Payload=%r",
                    payload,
                )
                raise HTTPException(
                    status_code=400,
                    detail="Missing ID_D",
                )

            if not signature:
                logger.error(
                    "GGsel webhook missing SHA256. Payload=%r",
                    payload,
                )
                raise HTTPException(
                    status_code=400,
                    detail="Missing SHA256",
                )

            invoice_id = str(invoice_id)
            product_id = str(product_id)
            # signature = str(signature)

            # if not self._verify_signature(
            #     invoice_id=invoice_id,
            #     product_id=product_id,
            #     signature=signature,
            # ):
            #     logger.warning(
            #         "Invalid GGsel webhook signature: "
            #         "invoice=%s",
            #         invoice_id,
            #     )
            #
            #     raise HTTPException(
            #         status_code=403,
            #         detail="Invalid signature",
            #     )

            is_new = await self.db.insert_webhook_sale(
                invoice_id=invoice_id,
                ggsel_product_id=int(product_id),
                amount=float(payload.get("amount", 0)),
                currency=str(payload.get("currency", "")),
                sale_date=str(payload.get("date", "")),
                raw_data=payload,
            )

            if not is_new:
                logger.info(
                    "Duplicate GGsel webhook: invoice=%s",
                    invoice_id,
                )

                return {"ok": True}

            logger.info(
                "New GGsel order: invoice=%s product=%s",
                invoice_id,
                product_id,
            )

            asyncio.create_task(
                self._process_order(invoice_id)
            )

            return {"ok": True}
        except Exception as e:
            logger.fatal(
                "GGsel webhook payload error: %s",
                str(e)
            )

    async def _process_order(
        self,
        invoice_id: str,
    ) -> None:
        try:
            await self.processor.process_by_invoice(
                invoice_id
            )

        except HTTPException:
            raise

        except Exception:
            logger.exception(
                "GGsel webhook processing failed"
            )
            raise HTTPException(
                status_code=500,
                detail="Internal server error",
            )