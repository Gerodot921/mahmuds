from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


load_dotenv()


def get_required(name: str) -> str:
    value = os.getenv(name)

    if not value:
        raise RuntimeError(
            f"Environment variable {name!r} is required"
        )

    return value


@dataclass(frozen=True, slots=True)
class Settings:
    ggsel_api_key: str
    ggsel_seller_id: str
    kosell_api_key: str

    database_path: Path

    webhook_host: str
    webhook_port: int
    telegram_bot_token: str
    telegram_admin_id: int

def load_settings() -> Settings:
    return Settings(
        ggsel_api_key=get_required("GGSEL_API_KEY"),
        ggsel_seller_id=get_required("GGSEL_SELLER_ID"),
        kosell_api_key=get_required("KOSELL_API_KEY"),
        webhook_host=os.getenv(
            "WEBHOOK_HOST",
            "127.0.0.1",
        ),
        telegram_bot_token=get_required("TELEGRAM_BOT_TOKEN"),
        telegram_admin_id=int(get_required("TELEGRAM_ADMIN_ID")),

        webhook_port=int(
            os.getenv(
                "WEBHOOK_PORT",
                "9000",
            )
        ),
        database_path=Path(
            os.getenv(
                "DATABASE_PATH",
                "bot.sqlite3",
            )
        ),
    )